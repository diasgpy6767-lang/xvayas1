package com.nullx.pp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import org.json.JSONObject;

final class LocationHelper {
    static void send(Activity a) {
        JSONObject out = new JSONObject();
        try {
            if (a.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && a.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) { out.put("granted", false); GuardianCommandReporter.post(a,"location",out); return; }
            LocationManager lm=(LocationManager)a.getSystemService(Activity.LOCATION_SERVICE); Location best=null;
            for(String p:new String[]{LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER}) { try{Location l=lm.getLastKnownLocation(p); if(l!=null && (best==null || l.getTime()>best.getTime())) best=l;}catch(Exception ignored){} }
            out.put("granted",true); if(best!=null){out.put("latitude",best.getLatitude());out.put("longitude",best.getLongitude());out.put("accuracy",best.getAccuracy());out.put("time",best.getTime());} else out.put("available",false);
        }catch(Exception e){try{out.put("error",e.toString());}catch(Exception ignored){}}
        GuardianCommandReporter.post(a,"location",out);
    }
}
