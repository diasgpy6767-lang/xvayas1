package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Starts the visible control channel after device boot without requiring the Guardian UI to be opened. */
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String a = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a)
                || Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(a)
                || "android.intent.action.QUICKBOOT_POWERON".equals(a)
                || "com.htc.intent.action.QUICKBOOT_POWERON".equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            try {
                DeviceService.loadCached(context);
                Intent control = new Intent(context, GuardianControlService.class);
                if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(control);
                else context.startService(control);
            } catch (Exception ignored) {}
        }
    }
}
