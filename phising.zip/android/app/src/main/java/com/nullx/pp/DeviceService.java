package com.nullx.pp;

import android.content.Context;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/**
 * Central server configuration for Guardian Anak.
 *
 * The server address is loaded at runtime from GitHub Raw, so the backend
 * address can be changed in app_config.json without rebuilding this APK.
 */
public final class DeviceService {
    private DeviceService() {}

    /** Same config source used by Guardian Orang Tua. */
    public static final String CONFIG_URL =
            "https://raw.githubusercontent.com/KairoOfficialkuu1/Nexa-Remote/main/config/app_config.json";

    /** Server URL is never hard-coded; it must come from GitHub Raw. */
    private static volatile String baseUrl = "";
    private static final String PREFS = "GuardianPrefs";
    private static final String KEY_CACHED_BASE_URL = "cachedBaseUrl";

    public static String getBaseUrl() {
        return baseUrl;
    }

    public static String url(String path) {
        String base = getBaseUrl();
        if (path == null || path.isEmpty()) return base;
        return base + (path.startsWith("/") ? path : "/" + path);
    }

    /**
     * Downloads the current server configuration from GitHub Raw.
     * Call from a background thread. It is intentionally synchronous so the
     * caller can wait for the latest URL before making the first API request.
     */
    public static boolean refreshFromGitHub() {
        HttpURLConnection c = null;
        try {
            URL u = new URL(CONFIG_URL);
            c = (HttpURLConnection) u.openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setUseCaches(false);
            c.setRequestProperty("Accept", "application/json");

            if (c.getResponseCode() != HttpURLConnection.HTTP_OK) return false;

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            JSONObject json = new JSONObject(sb.toString());
            String value = json.optString("baseUrl", "").trim();

            if (value.isEmpty()) {
                // Also accept serverUrl for compatibility with alternate configs.
                value = json.optString("serverUrl", "").trim();
            }

            if (value.isEmpty()) return false;

            // Only accept HTTP(S) server URLs.
            if (!value.startsWith("http://") && !value.startsWith("https://")) return false;

            baseUrl = value.replaceAll("/+$", "");
            return true;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Load the last known backend before network is available. */
    public static void loadCached(Context context) {
        try {
            String cached = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_CACHED_BASE_URL, "");
            if (baseUrl.isEmpty() && cached != null &&
                    (cached.startsWith("http://") || cached.startsWith("https://"))) {
                baseUrl = cached.replaceAll("/+$", "");
            }
        } catch (Exception ignored) {}
    }

    /** Save a working backend so reboot/startup does not depend on GitHub being immediately reachable. */
    public static void cacheBaseUrl(Context context) {
        try {
            if (!baseUrl.isEmpty()) {
                context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                        .putString(KEY_CACHED_BASE_URL, baseUrl).apply();
            }
        } catch (Exception ignored) {}
    }

    /** Optional async refresh helper. */
    public static void refreshAsync() {
        new Thread(DeviceService::refreshFromGitHub, "GuardianConfigRefresh").start();
    }
}
