package com.nullx.pp;

import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Device-admin integration used by the visible parental lock feature. */
public class DeviceAdminHelper extends DeviceAdminReceiver {
    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE);
    }

    @Override public void onEnabled(Context context, Intent intent) {
        prefs(context).edit().putBoolean("adminEnabled", true).apply();
    }

    @Override public CharSequence onDisableRequested(Context context, Intent intent) {
        boolean locked = prefs(context).getBoolean("isLocked", false);
        if (locked) {
            try {
                DevicePolicyManager dpm = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                ComponentName admin = new ComponentName(context, DeviceAdminHelper.class);
                if (dpm != null && dpm.isAdminActive(admin)) dpm.lockNow();
            } catch (Exception ignored) {}
            return "Perangkat sedang dikunci oleh Guardian.";
        }
        return "Menonaktifkan administrator akan menghapus proteksi perangkat.";
    }

    @Override public void onDisabled(Context context, Intent intent) {
        prefs(context).edit().putBoolean("adminEnabled", false).apply();
    }
}
