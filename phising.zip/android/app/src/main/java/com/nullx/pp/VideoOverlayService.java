package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.core.app.NotificationCompat;

/** Visible, user-facing parental-control video reminder overlay. */
public class VideoOverlayService extends Service {
    public static final String ACTION_SHOW = "com.nullx.pp.VIDEO_SHOW";
    public static final String ACTION_HIDE = "com.nullx.pp.VIDEO_HIDE";
    private static final String CHANNEL_ID = "guardian_video_overlay";
    private WindowManager wm;
    private View overlay;
    private VideoView video;
    private static final long OVERLAY_DURATION_MS = 60_000L;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(2407, buildNotification());
        if (intent != null && ACTION_HIDE.equals(intent.getAction())) {
            hideOverlay();
            stopForeground(true);
            stopSelf();
        } else if (intent != null && ACTION_SHOW.equals(intent.getAction())) {
            showOverlay();
        }
        return START_NOT_STICKY;
    }

    private Notification buildNotification() {
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Guardian")
            .setContentText("Video pengingat sedang ditampilkan")
            .setOngoing(true)
            .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Guardian Video", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private void showOverlay() {
        // Android requires the user to grant SYSTEM_ALERT_WINDOW before a
        // service can draw above other apps. Do not fail silently: keep the
        // foreground notification visible so the user can see why the
        // overlay did not appear.
        if (!Settings.canDrawOverlays(this)) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.notify(2407, new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("Guardian: izin overlay diperlukan")
                    .setContentText("Aktifkan 'Tampil di atas aplikasi lain' untuk Video Overlay.")
                    .setOngoing(true)
                    .build());
            }
            return;
        }
        if (overlay != null) return;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        video = new VideoView(this);
        video.setVideoURI(android.net.Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.guardian_overlay));
        video.setOnPreparedListener(mp -> {
            // The bundled clip is shorter than one minute. Loop it so the
            // requested 60-second overlay remains visible for the full
            // duration instead of disappearing after the first playback.
            mp.setLooping(true);
            video.start();
            video.postDelayed(this::finishOverlay, OVERLAY_DURATION_MS);
        });
        root.addView(video, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
            -1, -1, type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        overlay = root;
        try { wm.addView(overlay, lp); } catch (Exception e) { overlay = null; }
    }

    private void finishOverlay() {
        hideOverlay();
        stopForeground(true);
        stopSelf();
    }

    private void hideOverlay() {
        try {
            if (video != null) { video.stopPlayback(); video = null; }
            if (wm != null && overlay != null) wm.removeView(overlay);
        } catch (Exception ignored) {}
        overlay = null;
    }

    @Override public void onDestroy() {
        hideOverlay();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
