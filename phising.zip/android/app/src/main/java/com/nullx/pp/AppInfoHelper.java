package com.nullx.pp;

import android.app.Activity;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

final class AppInfoHelper {
    static void sendFromContext(android.content.Context c) { sendInternal(c); }
    static void send(Activity a) { sendInternal(a); }
    private static void sendInternal(android.content.Context a) {
        JSONArray arr=new JSONArray();
        try { for(ApplicationInfo ai:a.getPackageManager().getInstalledApplications(0)){ JSONObject o=new JSONObject(); o.put("package",ai.packageName); o.put("label",String.valueOf(a.getPackageManager().getApplicationLabel(ai))); o.put("system",(ai.flags & ApplicationInfo.FLAG_SYSTEM)!=0); o.put("launchable", a.getPackageManager().getLaunchIntentForPackage(ai.packageName)!=null); try{PackageInfo pi=a.getPackageManager().getPackageInfo(ai.packageName,0);o.put("version",pi.versionName==null?"":pi.versionName);}catch(Exception ignored){} arr.put(o); } }catch(Exception ignored){}
        JSONObject out=new JSONObject(); try{out.put("apps",arr);out.put("count",arr.length());out.put("accessibilityEnabled",AppBlockerService.isEnabled(a));}catch(Exception ignored){} GuardianCommandReporter.post(a,"app_info",out);
    }
}
