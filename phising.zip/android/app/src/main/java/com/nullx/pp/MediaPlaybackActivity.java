package com.nullx.pp;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.widget.VideoView;
import android.view.WindowManager;

public class MediaPlaybackActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        VideoView v = new VideoView(this); setContentView(v);
        String src = getIntent().getStringExtra("src");
        if (src == null || src.isEmpty()) { finish(); return; }
        try { v.setVideoURI(Uri.parse(src)); v.setOnPreparedListener(mp -> { mp.setLooping(false); v.start(); }); v.setOnCompletionListener(x -> finish()); } catch(Exception e) { finish(); }
    }
}
