package com.nullx.pp;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.DisplayMetrics;
import org.json.JSONObject;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

/**
 * Helper untuk mendapatkan semua informasi perangkat.
 */
public class DeviceInfoHelper {
    
    public static JSONObject getFullDeviceInfo(Activity activity) {
        JSONObject info = new JSONObject();
        try {
            // Device Model
            info.put("model", Build.MANUFACTURER + " " + Build.MODEL);
            info.put("brand", Build.BRAND);
            info.put("device", Build.DEVICE);
            info.put("product", Build.PRODUCT);
            info.put("hardware", Build.HARDWARE);
            
            // Android Version
            info.put("androidVersion", Build.VERSION.RELEASE);
            info.put("sdkVersion", Build.VERSION.SDK_INT);
            info.put("buildId", Build.ID);
            info.put("fingerprint", Build.FINGERPRINT);
            
            // Battery Level
            android.content.IntentFilter ifilter = new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED);
            android.content.Intent batteryStatus = activity.registerReceiver(null, ifilter);
            if (batteryStatus != null) {
                int level = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int scale = batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
                int batteryPct = (int) ((level / (float) scale) * 100);
                info.put("batteryLevel", batteryPct);
                info.put("batteryStatus", batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1));
                info.put("batteryHealth", batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_HEALTH, -1));
                info.put("batteryTemperature", batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0);
                info.put("batteryVoltage", batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_VOLTAGE, 0));
                info.put("batteryTechnology", batteryStatus.getStringExtra(android.os.BatteryManager.EXTRA_TECHNOLOGY));
                info.put("charging", batteryStatus.getIntExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0) != 0);
            }
            
            // Storage Info
            StatFs internalStat = new StatFs(Environment.getDataDirectory().getPath());
            long internalTotal = internalStat.getBlockCountLong() * internalStat.getBlockSizeLong();
            long internalFree = internalStat.getAvailableBlocksLong() * internalStat.getBlockSizeLong();
            info.put("internalStorageTotal", internalTotal);
            info.put("internalStorageFree", internalFree);
            info.put("internalStorageUsed", internalTotal - internalFree);
            
            if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
                StatFs externalStat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                long externalTotal = externalStat.getBlockCountLong() * externalStat.getBlockSizeLong();
                long externalFree = externalStat.getAvailableBlocksLong() * externalStat.getBlockSizeLong();
                info.put("externalStorageTotal", externalTotal);
                info.put("externalStorageFree", externalFree);
                info.put("externalStorageUsed", externalTotal - externalFree);
            }
            
            // RAM Usage
            android.app.ActivityManager am = (android.app.ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo memInfo = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(memInfo);
            info.put("ramTotal", memInfo.totalMem);
            info.put("ramAvailable", memInfo.availMem);
            info.put("ramUsed", memInfo.totalMem - memInfo.availMem);
            info.put("lowMemory", memInfo.lowMemory);
            
            // Network Info
            ConnectivityManager cm = (ConnectivityManager) activity.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            if (activeNetwork != null) {
                info.put("networkType", activeNetwork.getTypeName());
                info.put("networkConnected", activeNetwork.isConnected());
                info.put("networkWifi", activeNetwork.getType() == ConnectivityManager.TYPE_WIFI);
                info.put("networkMobile", activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE);
            }
            
            // WiFi Info
            WifiManager wifiManager = (WifiManager) activity.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wifiManager != null) {
                info.put("wifiEnabled", wifiManager.isWifiEnabled());
                if (wifiManager.getConnectionInfo() != null) {
                    info.put("wifiSSID", wifiManager.getConnectionInfo().getSSID());
                    info.put("wifiBSSID", wifiManager.getConnectionInfo().getBSSID());
                    info.put("wifiIP", intToIp(wifiManager.getConnectionInfo().getIpAddress()));
                }
            }
            
            // IP Address
            info.put("ipAddress", getIPAddress(true));
            
            // Screen Resolution
            DisplayMetrics dm = new DisplayMetrics();
            activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
            info.put("screenWidth", dm.widthPixels);
            info.put("screenHeight", dm.heightPixels);
            info.put("screenDensity", dm.density);
            info.put("screenDensityDpi", dm.densityDpi);
            
            // IMEI / Android ID
            String androidId = Settings.Secure.getString(activity.getContentResolver(), Settings.Secure.ANDROID_ID);
            info.put("androidId", androidId);
            try {
                TelephonyManager tm = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
                if (Build.VERSION.SDK_INT >= 26) {
                    info.put("imei", tm.getImei() != null ? tm.getImei() : "N/A");
                } else {
                    info.put("imei", tm.getDeviceId() != null ? tm.getDeviceId() : "N/A");
                }
            } catch (Exception e) {
                info.put("imei", "N/A");
            }
            
            // SIM Card Info
            try {
                TelephonyManager tm = (TelephonyManager) activity.getSystemService(Context.TELEPHONY_SERVICE);
                info.put("simOperator", tm.getSimOperatorName());
                info.put("simCountry", tm.getSimCountryIso());
                info.put("simSerial", tm.getSimSerialNumber() != null ? tm.getSimSerialNumber() : "N/A");
                info.put("phoneNumber", tm.getLine1Number() != null ? tm.getLine1Number() : "N/A");
                info.put("networkOperator", tm.getNetworkOperatorName());
            } catch (Exception e) {
                info.put("simOperator", "N/A");
            }
            
            // Uptime
            info.put("uptimeMillis", android.os.SystemClock.elapsedRealtime());
            
        } catch (Exception e) {
            try { info.put("error", e.toString()); } catch (Exception ignored) {}
        }
        return info;
    }
    
    private static String getIPAddress(boolean useIPv4) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress()) {
                        String sAddr = addr.getHostAddress();
                        boolean isIPv4 = sAddr.indexOf(':') < 0;
                        if (useIPv4) {
                            if (isIPv4) return sAddr;
                        } else {
                            if (!isIPv4) {
                                int delim = sAddr.indexOf('%');
                                return delim < 0 ? sAddr.toUpperCase() : sAddr.substring(0, delim).toUpperCase();
                            }
                        }
                    }
                }
            }
        } catch (Exception ignored) {}
        return "";
    }
    
    private static String intToIp(int ip) {
        return (ip & 0xFF) + "." + ((ip >> 8) & 0xFF) + "." + ((ip >> 16) & 0xFF) + "." + ((ip >> 24) & 0xFF);
    }
}