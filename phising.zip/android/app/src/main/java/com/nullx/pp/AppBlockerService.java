package com.nullx.pp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;
import org.json.JSONArray;
import java.util.HashSet;
import java.util.Set;

/**
 * Guardian parental-control app blocker.
 * Uses Android AccessibilityService because UsageStats polling alone is not
 * reliable for detecting the foreground app on modern Android versions.
 * The user must explicitly enable this service in Android Accessibility settings.
 */
public class AppBlockerService extends AccessibilityService {
    public static final String ACTION_BLOCK_APP = "com.nullx.pp.BLOCK_APP";
    public static final String ACTION_UNBLOCK_APP = "com.nullx.pp.UNBLOCK_APP";
    public static final String ACTION_UNBLOCK_ALL = "com.nullx.pp.UNBLOCK_ALL";

    private static final Set<String> BLOCKED_PACKAGES = new HashSet<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private BroadcastReceiver commandReceiver;
    private String lastBlockedPkg = "";
    private long lastBlockTime = 0L;

    public static boolean isEnabled(Context context) {
        try {
            String enabled = Settings.Secure.getString(
                    context.getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (enabled == null) return false;
            String component = context.getPackageName() + "/" + context.getPackageName() + ".AppBlockerService";
            String shortComponent = context.getPackageName() + "/.AppBlockerService";
            for (String service : enabled.split(":")) {
                if (service.equalsIgnoreCase(component) || service.equalsIgnoreCase(shortComponent)) return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        loadBlockedApps();

        AccessibilityServiceInfo info = getServiceInfo();
        if (info == null) info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 0;
        setServiceInfo(info);

        commandReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                String pkg = intent.getStringExtra("package");
                if (ACTION_BLOCK_APP.equals(action) && pkg != null && !pkg.isEmpty()) {
                    BLOCKED_PACKAGES.add(pkg);
                    saveBlockedApps();
                } else if (ACTION_UNBLOCK_APP.equals(action) && pkg != null) {
                    BLOCKED_PACKAGES.remove(pkg);
                    saveBlockedApps();
                } else if (ACTION_UNBLOCK_ALL.equals(action)) {
                    BLOCKED_PACKAGES.clear();
                    saveBlockedApps();
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(ACTION_BLOCK_APP);
        filter.addAction(ACTION_UNBLOCK_APP);
        filter.addAction(ACTION_UNBLOCK_ALL);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(commandReceiver, filter);
        }
    }

    private void loadBlockedApps() {
        try {
            String json = getSharedPreferences("GuardianPrefs", MODE_PRIVATE)
                    .getString("blockedApps", "[]");
            JSONArray arr = new JSONArray(json);
            synchronized (BLOCKED_PACKAGES) {
                BLOCKED_PACKAGES.clear();
                for (int i = 0; i < arr.length(); i++) BLOCKED_PACKAGES.add(arr.getString(i));
            }
        } catch (Exception ignored) {}
    }

    private void saveBlockedApps() {
        try {
            JSONArray arr = new JSONArray();
            synchronized (BLOCKED_PACKAGES) {
                for (String pkg : BLOCKED_PACKAGES) arr.put(pkg);
            }
            getSharedPreferences("GuardianPrefs", MODE_PRIVATE)
                    .edit().putString("blockedApps", arr.toString()).apply();
        } catch (Exception ignored) {}
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence packageName = event.getPackageName();
        if (packageName == null) return;
        String pkg = packageName.toString();
        if (pkg.equals(getPackageName()) || pkg.equals("android") || pkg.equals("com.android.systemui")) return;

        synchronized (BLOCKED_PACKAGES) {
            if (!BLOCKED_PACKAGES.contains(pkg)) return;
        }

        long now = System.currentTimeMillis();
        if (pkg.equals(lastBlockedPkg) && now - lastBlockTime < 1000) return;
        lastBlockedPkg = pkg;
        lastBlockTime = now;

        // Return to Home immediately instead of attempting to force-close another app.
        performGlobalAction(GLOBAL_ACTION_HOME);
        handler.postDelayed(() -> performGlobalAction(GLOBAL_ACTION_HOME), 100);

        String appName = pkg;
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                appName = getPackageManager().getApplicationLabel(
                        getPackageManager().getApplicationInfo(
                                pkg, PackageManager.ApplicationInfoFlags.of(0))).toString();
            } else {
                appName = getPackageManager().getApplicationLabel(
                        getPackageManager().getApplicationInfo(pkg, 0)).toString();
            }
        } catch (Exception ignored) {}

        final String label = appName;
        handler.post(() -> Toast.makeText(this,
                "Aplikasi diblokir: " + label, Toast.LENGTH_SHORT).show());
    }

    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        if (commandReceiver != null) {
            try { unregisterReceiver(commandReceiver); } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
