package com.nullx.pp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;

final class PermissionHelper {
    private PermissionHelper() {}
    static JSONObject snapshot(Activity a) {
        JSONObject o = new JSONObject();
        try { o.put("camera", Build.VERSION.SDK_INT < 23 || a.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED); } catch(Exception ignored){}
        try { o.put("microphone", Build.VERSION.SDK_INT < 23 || a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED); } catch(Exception ignored){}
        try { o.put("fine_location", Build.VERSION.SDK_INT < 23 || a.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED); } catch(Exception ignored){}
        try { o.put("coarse_location", Build.VERSION.SDK_INT < 23 || a.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED); } catch(Exception ignored){}
        try { o.put("notifications", Build.VERSION.SDK_INT < 33 || a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED); } catch(Exception ignored){}
        try { o.put("overlay", android.provider.Settings.canDrawOverlays(a)); } catch(Exception ignored){}
        return o;
    }
    static String[] requestable(Activity a) {
        java.util.ArrayList<String> p = new java.util.ArrayList<>();
        if (Build.VERSION.SDK_INT >= 23) {
            if (a.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.CAMERA);
            if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.RECORD_AUDIO);
            if (a.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.ACCESS_FINE_LOCATION);
            if (Build.VERSION.SDK_INT >= 33 && a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        return p.toArray(new String[0]);
    }
}
