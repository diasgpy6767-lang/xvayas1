package com.nullx.pp;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

/**
 * Visible HTML lock screen launched by the persistent Guardian control service.
 *
 * The lock is intentionally user-visible. Android screen-pinning/lock-task is
 * used where the OS permits it; Device Admin alone does not grant device-owner
 * privileges, so Android may still require its normal screen-pinning flow.
 */
public class HtmlLockActivity extends Activity {
    public static final String ACTION_STOP_HTML = "com.nullx.pp.ACTION_STOP_HTML";
    private static final String PREFS = "GuardianPrefs";
    private WebView webView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (ACTION_STOP_HTML.equals(getIntent().getAction())) {
            stopAndFinish();
            return;
        }

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        enterImmersive();

        String html = getIntent().getStringExtra("html");
        if (html == null || html.trim().isEmpty()) {
            html = "<html><body style='font-family:sans-serif;text-align:center;padding:40px'><h1>Guardian</h1><p>Perangkat sedang dikunci oleh kontrol orang tua.</p></body></html>";
        }

        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("htmlLocked", true)
                .putString("htmlLockContent", html)
                .apply();

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.requestFocus();
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        setContentView(webView);

        // Request Android screen-pinning/lock-task. On a normal non-device-owner
        // installation Android controls the confirmation UX.
        new android.os.Handler(getMainLooper()).postDelayed(this::enterLockTask, 150);
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (ACTION_STOP_HTML.equals(intent.getAction())) stopAndFinish();
    }

    @Override protected void onResume() {
        super.onResume();
        enterImmersive();
        if (getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean("htmlLocked", false)) {
            new android.os.Handler(getMainLooper()).postDelayed(this::enterLockTask, 100);
        }
    }

    private void enterImmersive() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = getWindow().getInsetsController();
                if (c != null) {
                    c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                    c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (Exception ignored) {}
    }

    private void enterLockTask() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                if (am != null && am.getLockTaskModeState() != ActivityManager.LOCK_TASK_MODE_NONE) return;
            }
            startLockTask();
        } catch (SecurityException ignored) {
            // Android may require the user/system to allow screen pinning.
        } catch (Exception ignored) {}
    }

    private void stopAndFinish() {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean("htmlLocked", false)
                .remove("htmlLockContent")
                .apply();
        try { stopLockTask(); } catch (Exception ignored) {}
        try { if (webView != null) webView.stopLoading(); } catch (Exception ignored) {}
        finishAndRemoveTask();
    }

    @Override public void onBackPressed() {
        // Back is intentionally ignored while HTML Lock is active. The parent
        // must send stop_html; Android still controls system-level escape paths.
    }
}
