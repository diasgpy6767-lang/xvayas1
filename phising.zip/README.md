# Guardian Anak - Persistent Control v4

Perubahan utama:
- GuardianControlService tetap menjadi channel kontrol persistent dan tidak bergantung pada MainActivity untuk command dasar.
- Saat command kontrol dari Guardian Orang Tua diterima, Guardian Anak mencoba membawa UI Guardian Anak ke foreground.
- File Manager berjalan dari service sehingga tidak bergantung pada Activity.
- Android 11+ meminta izin resmi `MANAGE_EXTERNAL_STORAGE` / "Kelola semua file" dari pemilik perangkat.
- HTML Lock menggunakan Activity fullscreen yang terlihat pengguna, menyimpan state lock, dan meminta Android screen-pinning/lock-task. Lock hanya dilepas melalui `stop_html` atau mekanisme sistem Android.
- HTML Lock dipulihkan setelah service/process restart selama state lock masih aktif.
- Konfigurasi server Guardian Orang Tua/GitHub Raw tidak diubah oleh paket ini.

Catatan Android:
- Android/OEM tetap dapat membatasi background activity/service.
- Device Admin bukan Device Owner dan tidak otomatis memberikan izin lock-task permanen.
- Screen capture/camera/recording tetap mengikuti izin dan pembatasan Android.
